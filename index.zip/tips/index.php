<?php
$kategoriSlug = 'tips';
include '../includes/kategori-template.php';
