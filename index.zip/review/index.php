<?php
$kategoriSlug = 'review';
include '../includes/kategori-template.php';
