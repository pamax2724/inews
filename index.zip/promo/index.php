<?php
$kategoriSlug = 'promo';
include '../includes/kategori-template.php';
