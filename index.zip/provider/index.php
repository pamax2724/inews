<?php
$kategoriSlug = 'provider';
include '../includes/kategori-template.php';
