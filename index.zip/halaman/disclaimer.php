<?php
$halamanSlug = 'disclaimer';
include '../includes/halaman-template.php';
