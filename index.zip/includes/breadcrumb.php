<?php
// $breadcrumbItems = [['name' => 'Home', 'url' => BASE_URL], ...]
if (!isset($breadcrumbItems) || empty($breadcrumbItems)) return;
?>
<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
        <?php foreach ($breadcrumbItems as $i => $item): ?>
        <?php if ($i === count($breadcrumbItems) - 1): ?>
        <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($item['name']) ?></li>
        <?php else: ?>
        <li class="breadcrumb-item"><a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['name']) ?></a></li>
        <?php endif; ?>
        <?php endforeach; ?>
    </ol>
</nav>
