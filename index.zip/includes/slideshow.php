<?php
$slides = getSlideshow();
if (empty($slides)) return;
?>
<!-- Slideshow -->
<style>
#mainSlideshow .carousel-item img {
    width: 100%;
    height: auto !important;
    max-height: none !important;
    object-fit: fill;
}
</style>
<div id="mainSlideshow" class="carousel slide mb-4" data-bs-ride="carousel" data-bs-interval="5000">
    <div class="carousel-indicators">
        <?php foreach ($slides as $i => $slide): ?>
        <button type="button" data-bs-target="#mainSlideshow" data-bs-slide-to="<?= $i ?>" <?= $i === 0 ? 'class="active"' : '' ?>></button>
        <?php endforeach; ?>
    </div>
    <div class="carousel-inner rounded-3 overflow-hidden">
        <?php foreach ($slides as $i => $slide): ?>
        <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
            <a href="<?= htmlspecialchars($slide['link']) ?>" rel="nofollow noopener" target="_blank">
                <img src="<?= htmlspecialchars($slide['gambar']) ?>" class="d-block" style="width:100%; height:auto;" alt="Banner <?= $i + 1 ?>">
            </a>
        </div>
        <?php endforeach; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#mainSlideshow" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#mainSlideshow" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>
