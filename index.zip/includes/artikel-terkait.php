<?php
// $artikelTerkait harus di-set sebelum include file ini
if (!isset($artikelTerkait) || empty($artikelTerkait)) return;
?>
<!-- Artikel Terkait -->
<div class="artikel-terkait mt-5">
    <h5 class="text-warning mb-3"><i class="bi bi-collection"></i> Artikel Terkait</h5>
    <div class="row g-3">
        <?php foreach ($artikelTerkait as $at): ?>
        <div class="col-md-6 col-lg-3">
            <div class="card bg-dark border-secondary h-100 card-hover">
                <a href="<?= BASE_URL ?>/<?= $at['kategori'] ?>/<?= $at['slug'] ?>.html">
                    <img src="<?= htmlspecialchars($at['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($at['judul']) ?>">
                </a>
                <div class="card-body">
                    <a href="<?= BASE_URL ?>/<?= $at['kategori'] ?>/<?= $at['slug'] ?>.html" class="text-decoration-none">
                        <h6 class="card-title text-light"><?= htmlspecialchars($at['judul']) ?></h6>
                    </a>
                    <small class="text-light-emphasis">
                        <i class="bi bi-calendar"></i> <?= formatTanggal($at['created_at']) ?>
                    </small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
