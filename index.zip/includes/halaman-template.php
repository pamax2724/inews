<?php
require_once __DIR__ . '/functions.php';

// $halamanSlug harus di-set dari file yang include
if (!isset($halamanSlug)) {
    header('Location: ' . BASE_URL);
    exit;
}

$halaman = getHalamanBySlug($halamanSlug);

if (!$halaman) {
    header('HTTP/1.0 404 Not Found');
    include BASE_PATH . '/404.php';
    exit;
}

// Page meta
$pageTitle = $halaman['judul'] . ' - ' . getSetting('nama_web');
$pageDesc = truncate($halaman['isi'], 160);
$pageUrl = BASE_URL . '/halaman/' . $halamanSlug . '.html';

// Breadcrumb
$breadcrumbItems = [
    ['name' => 'Home', 'url' => BASE_URL],
    ['name' => $halaman['judul'], 'url' => $pageUrl]
];

$schemaBreadcrumb = generateSchemaBreadcrumb($breadcrumbItems);

include BASE_PATH . '/includes/header.php';
?>

<main class="py-4">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Breadcrumb -->
                <?php include BASE_PATH . '/includes/breadcrumb.php'; ?>

                <article class="article-content">
                    <h1 class="text-light mb-4"><?= htmlspecialchars($halaman['judul']) ?></h1>

                    <div class="article-body text-light">
                        <?= $halaman['isi'] ?>
                    </div>
                </article>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <?php include BASE_PATH . '/includes/sidebar.php'; ?>
            </div>
        </div>
    </div>
</main>

<?php include BASE_PATH . '/includes/footer.php'; ?>
