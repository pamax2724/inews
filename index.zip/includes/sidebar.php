<?php
$beritaPopuler = getBeritaPopuler(5);
$backlinks = loadJson('backlinks.json');
$backlinks = array_filter($backlinks, fn($b) => $b['aktif'] ?? false);
usort($backlinks, fn($a, $b) => ($a['urutan'] ?? 0) - ($b['urutan'] ?? 0));
?>
<!-- Sidebar -->
<div class="sidebar">
    <!-- 1. Search -->
    <div class="card bg-dark border-secondary mb-4">
        <div class="card-body">
            <h6 class="card-title text-warning"><i class="bi bi-search"></i> Cari Berita</h6>
            <form action="<?= BASE_URL ?>/cari.php" method="GET">
                <div class="input-group">
                    <input type="text" name="q" class="form-control bg-secondary border-0 text-light" placeholder="Kata kunci...">
                    <button class="btn btn-warning" type="submit"><i class="bi bi-search"></i></button>
                </div>
            </form>
        </div>
    </div>

    <!-- 2. Kategori -->
    <div class="card bg-dark border-secondary mb-4">
        <div class="card-body">
            <h6 class="card-title text-warning"><i class="bi bi-folder"></i> Kategori</h6>
            <ul class="list-unstyled mb-0">
                <?php foreach ($kategoriList as $kat): ?>
                <li class="mb-1">
                    <a href="<?= BASE_URL ?>/<?= $kat['id'] ?>/" class="text-light text-decoration-none">
                        <i class="bi bi-chevron-right"></i> <?= htmlspecialchars($kat['nama']) ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- 3. Berita Populer -->
    <?php if (!empty($beritaPopuler)): ?>
    <div class="card bg-dark border-secondary mb-4">
        <div class="card-body">
            <h6 class="card-title text-warning"><i class="bi bi-fire"></i> Berita Populer</h6>
            <ul class="list-unstyled mb-0">
                <?php foreach ($beritaPopuler as $bp): ?>
                <li class="mb-2 pb-2 border-bottom border-secondary">
                    <a href="<?= BASE_URL ?>/<?= $bp['kategori'] ?>/<?= $bp['slug'] ?>.html" class="text-light text-decoration-none small">
                        <?= htmlspecialchars($bp['judul']) ?>
                    </a>
                    <div class="text-light-emphasis" style="font-size: 0.75rem;">
                        <i class="bi bi-eye"></i> <?= number_format($bp['views'] ?? 0) ?> views
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <!-- 4. Backlinks -->
    <?php if (!empty($backlinks)): ?>
    <div class="card bg-dark border-secondary">
        <div class="card-body">
            <h6 class="card-title text-warning"><i class="bi bi-link-45deg"></i> Link Terkait</h6>
            <ul class="list-unstyled mb-0">
                <?php foreach ($backlinks as $bl): ?>
                <li class="mb-2">
                    <a href="<?= htmlspecialchars($bl['url']) ?>" class="text-warning text-decoration-none" target="_blank">
                        <i class="bi bi-chevron-right"></i> <?= htmlspecialchars($bl['anchor']) ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>
</div>
