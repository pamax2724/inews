<?php
$halamanList = getAllHalaman();
?>
    <!-- Footer -->
    <footer class="mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="text-warning"><i class="bi bi-joystick"></i> <?= htmlspecialchars($setting['nama_web']) ?></h5>
                    <p class="text-light-emphasis"><?= htmlspecialchars($setting['tagline']) ?></p>
                </div>
                <div class="col-md-4 mb-3">
                    <h6 class="text-warning">Kategori</h6>
                    <ul class="list-unstyled">
                        <?php foreach ($kategoriList as $kat): ?>
                        <li><a href="<?= BASE_URL ?>/<?= $kat['id'] ?>/" class="text-light-emphasis text-decoration-none"><?= htmlspecialchars($kat['nama']) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h6 class="text-warning">Halaman</h6>
                    <ul class="list-unstyled">
                        <?php foreach ($halamanList as $hal): ?>
                        <?php if ($hal['aktif'] ?? true): ?>
                        <li><a href="<?= BASE_URL ?>/halaman/<?= $hal['slug'] ?>.html" class="text-light-emphasis text-decoration-none"><?= htmlspecialchars($hal['judul']) ?></a></li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="text-center text-light-emphasis">
                <small>&copy; <?= date('Y') ?> <?= htmlspecialchars($setting['nama_web']) ?>. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
