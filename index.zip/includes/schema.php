<?php
// Schema JSON-LD Generator

function generateSchemaOrganization() {
    $setting = getSetting();
    $schema = [
        '@type' => 'Organization',
        'name' => $setting['nama_web'],
        'url' => BASE_URL
    ];
    // Only add logo if exists
    if (!empty($setting['logo'])) {
        $schema['logo'] = $setting['logo'];
    } elseif (!empty($setting['og_image'])) {
        $schema['logo'] = $setting['og_image'];
    }
    return $schema;
}

function generateSchemaWebsite() {
    $setting = getSetting();
    return [
        '@context' => 'https://schema.org',
        '@type' => 'WebSite',
        'name' => $setting['nama_web'],
        'url' => BASE_URL,
        'description' => $setting['meta_desc'],
        'potentialAction' => [
            '@type' => 'SearchAction',
            'target' => BASE_URL . '/cari.php?q={search_term_string}',
            'query-input' => 'required name=search_term_string'
        ]
    ];
}

function generateSchemaArticle($berita) {
    $setting = getSetting();

    // Generate rating untuk artikel ini
    $rating = $berita['rating'] ?? generateRating();
    $reviewCount = $berita['review_count'] ?? generateReviewCount();

    return [
        '@context' => 'https://schema.org',
        '@type' => 'Article',
        'mainEntityOfPage' => [
            '@type' => 'WebPage',
            '@id' => BASE_URL . '/' . $berita['kategori'] . '/' . $berita['slug'] . '.html'
        ],
        'headline' => $berita['judul'],
        'description' => truncate($berita['isi'], 160),
        'image' => $berita['gambar'],
        'datePublished' => $berita['created_at'],
        'dateModified' => $berita['updated_at'] ?? $berita['created_at'],
        'author' => [
            '@type' => 'Organization',
            'name' => $setting['nama_web']
        ],
        'publisher' => [
            '@type' => 'Organization',
            'name' => $setting['nama_web'],
            'logo' => [
                '@type' => 'ImageObject',
                'url' => !empty($setting['logo']) ? $setting['logo'] : ($setting['og_image'] ?? '')
            ]
        ],
        'aggregateRating' => [
            '@type' => 'AggregateRating',
            'ratingValue' => $rating,
            'bestRating' => '5',
            'worstRating' => '1',
            'ratingCount' => $reviewCount
        ]
    ];
}

function generateSchemaBreadcrumb($items) {
    $list = [];
    foreach ($items as $i => $item) {
        $list[] = [
            '@type' => 'ListItem',
            'position' => $i + 1,
            'name' => $item['name'],
            'item' => $item['url']
        ];
    }

    return [
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        'itemListElement' => $list
    ];
}

function outputSchema($schema) {
    echo '<script type="application/ld+json">' . "\n";
    echo json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    echo "\n</script>\n";
}
?>
