<?php
require_once __DIR__ . '/functions.php';

// $kategori harus di-set dari file yang include
if (!isset($kategoriSlug)) {
    header('Location: ' . BASE_URL);
    exit;
}

$kategoriInfo = getKategoriBySlug($kategoriSlug);

if (!$kategoriInfo) {
    header('HTTP/1.0 404 Not Found');
    include BASE_PATH . '/404.php';
    exit;
}

$beritaList = getBeritaByKategori($kategoriSlug);

// Page meta
$pageTitle = $kategoriInfo['nama'] . ' - ' . getSetting('nama_web');
$pageDesc = $kategoriInfo['deskripsi'] ?? 'Berita kategori ' . $kategoriInfo['nama'];
$pageUrl = BASE_URL . '/' . $kategoriSlug . '/';

// Breadcrumb
$breadcrumbItems = [
    ['name' => 'Home', 'url' => BASE_URL],
    ['name' => $kategoriInfo['nama'], 'url' => $pageUrl]
];

$schemaBreadcrumb = generateSchemaBreadcrumb($breadcrumbItems);

include BASE_PATH . '/includes/header.php';
?>

<main class="py-4">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Breadcrumb -->
                <?php include BASE_PATH . '/includes/breadcrumb.php'; ?>

                <h4 class="text-warning mb-3"><i class="bi bi-folder"></i> <?= htmlspecialchars($kategoriInfo['nama']) ?></h4>
                <p class="text-light-emphasis mb-4"><?= htmlspecialchars($kategoriInfo['deskripsi'] ?? '') ?></p>

                <?php if (empty($beritaList)): ?>
                <div class="alert alert-secondary">
                    <i class="bi bi-info-circle"></i> Belum ada berita di kategori ini.
                </div>
                <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($beritaList as $berita): ?>
                    <div class="col-md-6">
                        <div class="card bg-dark border-secondary h-100 card-hover">
                            <a href="<?= BASE_URL ?>/<?= $berita['kategori'] ?>/<?= $berita['slug'] ?>.html">
                                <img src="<?= htmlspecialchars($berita['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($berita['judul']) ?>">
                            </a>
                            <div class="card-body">
                                <a href="<?= BASE_URL ?>/<?= $berita['kategori'] ?>/<?= $berita['slug'] ?>.html" class="text-decoration-none">
                                    <h5 class="card-title text-light"><?= htmlspecialchars($berita['judul']) ?></h5>
                                </a>
                                <p class="card-text text-light-emphasis small"><?= truncate($berita['isi'], 100) ?></p>
                            </div>
                            <div class="card-footer bg-transparent border-secondary">
                                <small class="text-light-emphasis">
                                    <i class="bi bi-calendar"></i> <?= formatTanggal($berita['created_at']) ?>
                                    <span class="ms-2"><i class="bi bi-eye"></i> <?= number_format($berita['views'] ?? 0) ?></span>
                                </small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <?php include BASE_PATH . '/includes/sidebar.php'; ?>
            </div>
        </div>
    </div>
</main>

<?php include BASE_PATH . '/includes/footer.php'; ?>
