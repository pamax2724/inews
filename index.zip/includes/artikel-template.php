<?php
require_once __DIR__ . '/functions.php';

// $kategori dan $slug harus di-set dari file yang include
if (!isset($kategori) || !isset($slug)) {
    header('Location: ' . BASE_URL);
    exit;
}

$berita = getBeritaBySlug($kategori, $slug);

if (!$berita || $berita['status'] !== 'publish') {
    header('HTTP/1.0 404 Not Found');
    include BASE_PATH . '/404.php';
    exit;
}

// Increment views
incrementViews($berita['id']);

// Get related articles
$artikelTerkait = getArtikelTerkait($kategori, $berita['id'], 4);

// Get berita lainnya (random from all categories)
$beritaLainnya = getBeritaLainnya($berita['id'], 6);

// Get kategori info
$kategoriInfo = getKategoriBySlug($kategori);

// Page meta
$pageTitle = $berita['judul'] . ' - ' . getSetting('nama_web');
$pageDesc = truncate($berita['isi'], 160);
$pageImage = $berita['gambar'];
$pageUrl = BASE_URL . '/' . $kategori . '/' . $slug . '.html';
// Keywords dari tags artikel, atau fallback ke default
$pageKeywords = !empty($berita['tags']) ? implode(', ', $berita['tags']) : getSetting('meta_keywords');

// Breadcrumb
$breadcrumbItems = [
    ['name' => 'Home', 'url' => BASE_URL],
    ['name' => $kategoriInfo['nama'] ?? ucfirst($kategori), 'url' => BASE_URL . '/' . $kategori . '/'],
    ['name' => $berita['judul'], 'url' => $pageUrl]
];

// Schema
$schemaArticle = generateSchemaArticle($berita);
$schemaBreadcrumb = generateSchemaBreadcrumb($breadcrumbItems);

include BASE_PATH . '/includes/header.php';
?>

<main class="py-4">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Breadcrumb -->
                <?php include BASE_PATH . '/includes/breadcrumb.php'; ?>

                <article class="article-content">
                    <h1 class="text-light mb-3"><?= htmlspecialchars($berita['judul']) ?></h1>

                    <div class="article-meta mb-3 text-light-emphasis">
                        <span><i class="bi bi-calendar"></i> <?= formatTanggal($berita['created_at']) ?></span>
                        <span class="ms-3"><i class="bi bi-folder"></i> <a href="<?= BASE_URL ?>/<?= $kategori ?>/" class="text-warning text-decoration-none"><?= htmlspecialchars($kategoriInfo['nama'] ?? ucfirst($kategori)) ?></a></span>
                        <span class="ms-3"><i class="bi bi-eye"></i> <?= number_format($berita['views'] ?? 0) ?> views</span>
                        <span class="ms-3"><i class="bi bi-clock"></i> <?= readingTime($berita['isi']) ?></span>
                    </div>

                    <?php if (!empty($berita['gambar'])): ?>
                    <div class="article-image mb-4">
                        <img src="<?= htmlspecialchars($berita['gambar']) ?>" class="img-fluid rounded" alt="<?= htmlspecialchars($berita['judul']) ?>">
                    </div>
                    <?php endif; ?>

                    <div class="article-body text-light">
                        <?= $berita['isi'] ?>
                    </div>

                    <!-- Tags -->
                    <?php if (!empty($berita['tags'])): ?>
                    <div class="article-tags mt-4">
                        <i class="bi bi-tags text-warning"></i>
                        <?php foreach ($berita['tags'] as $tag): ?>
                        <span class="badge bg-secondary"><?= htmlspecialchars($tag) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Share -->
                    <div class="article-share mt-4 p-3 bg-dark rounded">
                        <span class="text-warning me-2"><i class="bi bi-share"></i> Bagikan:</span>
                        <a href="https://wa.me/?text=<?= urlencode($berita['judul'] . ' ' . $pageUrl) ?>" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-success">
                            <i class="bi bi-whatsapp"></i> WhatsApp
                        </a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($pageUrl) ?>" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-primary">
                            <i class="bi bi-facebook"></i> Facebook
                        </a>
                        <a href="https://twitter.com/intent/tweet?url=<?= urlencode($pageUrl) ?>&text=<?= urlencode($berita['judul']) ?>" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-info">
                            <i class="bi bi-twitter"></i> Twitter
                        </a>
                        <a href="https://t.me/share/url?url=<?= urlencode($pageUrl) ?>&text=<?= urlencode($berita['judul']) ?>" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-primary">
                            <i class="bi bi-telegram"></i> Telegram
                        </a>
                    </div>

                    <!-- Berita Lainnya -->
                    <?php if (!empty($beritaLainnya)): ?>
                    <div class="berita-lainnya mt-4">
                        <h5 class="text-warning mb-3"><i class="bi bi-newspaper"></i> Berita Lainnya yang Mungkin Anda Suka</h5>
                        <div class="row g-3">
                            <?php foreach ($beritaLainnya as $bl): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card bg-dark border-secondary h-100 card-hover">
                                    <a href="<?= BASE_URL ?>/<?= $bl['kategori'] ?>/<?= $bl['slug'] ?>.html">
                                        <img src="<?= htmlspecialchars($bl['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($bl['judul']) ?>" style="height: 120px; object-fit: cover;">
                                    </a>
                                    <div class="card-body p-2">
                                        <a href="<?= BASE_URL ?>/<?= $bl['kategori'] ?>/<?= $bl['slug'] ?>.html" class="text-decoration-none">
                                            <h6 class="card-title text-light mb-1" style="font-size: 0.9rem;"><?= htmlspecialchars(truncate($bl['judul'], 50)) ?></h6>
                                        </a>
                                        <small class="text-light-emphasis">
                                            <i class="bi bi-folder"></i> <?= htmlspecialchars(ucfirst($bl['kategori'])) ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </article>

                <!-- Artikel Terkait -->
                <?php include BASE_PATH . '/includes/artikel-terkait.php'; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <?php include BASE_PATH . '/includes/sidebar.php'; ?>
            </div>
        </div>
    </div>
</main>

<?php include BASE_PATH . '/includes/footer.php'; ?>
