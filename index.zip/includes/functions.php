<?php
// Base URL
define('BASE_URL', 'https://sandboxlrs.accme.org');
define('BASE_PATH', dirname(__DIR__));

// Include schema functions
require_once __DIR__ . '/schema.php';

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Load JSON data
function loadJson($file) {
    $path = BASE_PATH . '/data/' . $file;
    if (file_exists($path)) {
        return json_decode(file_get_contents($path), true) ?: [];
    }
    return [];
}

// Save JSON data
function saveJson($file, $data) {
    $path = BASE_PATH . '/data/' . $file;
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

// Get setting
function getSetting($key = null) {
    $setting = loadJson('setting.json');
    if ($key) {
        return $setting[$key] ?? '';
    }
    return $setting;
}

// Get all berita
function getAllBerita($limit = null, $status = 'publish') {
    $berita = loadJson('berita.json');
    $berita = array_filter($berita, fn($b) => $b['status'] === $status);
    usort($berita, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));
    if ($limit) {
        return array_slice($berita, 0, $limit);
    }
    return $berita;
}

// Get berita by slug
function getBeritaBySlug($kategori, $slug) {
    $berita = loadJson('berita.json');
    foreach ($berita as $b) {
        if ($b['kategori'] === $kategori && $b['slug'] === $slug) {
            return $b;
        }
    }
    return null;
}

// Get berita by ID
function getBeritaById($id) {
    $berita = loadJson('berita.json');
    foreach ($berita as $b) {
        if ($b['id'] == $id) {
            return $b;
        }
    }
    return null;
}

// Get berita by kategori
function getBeritaByKategori($kategori, $limit = null) {
    $berita = loadJson('berita.json');
    $berita = array_filter($berita, fn($b) => $b['kategori'] === $kategori && $b['status'] === 'publish');
    usort($berita, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));
    if ($limit) {
        return array_slice($berita, 0, $limit);
    }
    return array_values($berita);
}

// Get berita populer (by views)
function getBeritaPopuler($limit = 5) {
    $berita = loadJson('berita.json');
    $berita = array_filter($berita, fn($b) => $b['status'] === 'publish');
    usort($berita, fn($a, $b) => ($b['views'] ?? 0) - ($a['views'] ?? 0));
    return array_slice($berita, 0, $limit);
}

// Get artikel terkait
function getArtikelTerkait($kategori, $currentId, $limit = 4) {
    $berita = loadJson('berita.json');
    $berita = array_filter($berita, fn($b) => $b['kategori'] === $kategori && $b['id'] != $currentId && $b['status'] === 'publish');
    usort($berita, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));
    return array_slice(array_values($berita), 0, $limit);
}

// Get berita lainnya (random from all categories, excluding current)
function getBeritaLainnya($currentId, $limit = 6) {
    $berita = loadJson('berita.json');
    $berita = array_filter($berita, fn($b) => $b['id'] != $currentId && $b['status'] === 'publish');
    $berita = array_values($berita);
    shuffle($berita);
    return array_slice($berita, 0, $limit);
}

// Increment views
function incrementViews($id) {
    $berita = loadJson('berita.json');
    foreach ($berita as &$b) {
        if ($b['id'] == $id) {
            $b['views'] = ($b['views'] ?? 0) + 1;
            break;
        }
    }
    saveJson('berita.json', $berita);
}

// Get kategori
function getAllKategori() {
    return loadJson('kategori.json');
}

function getKategoriBySlug($slug) {
    $kategori = loadJson('kategori.json');
    foreach ($kategori as $k) {
        if ($k['id'] === $slug) {
            return $k;
        }
    }
    return null;
}

// Get slideshow
function getSlideshow() {
    $slides = loadJson('slideshow.json');
    $slides = array_filter($slides, fn($s) => $s['aktif'] ?? false);
    usort($slides, fn($a, $b) => ($a['urutan'] ?? 0) - ($b['urutan'] ?? 0));
    return array_values($slides);
}

// Get halaman
function getAllHalaman() {
    return loadJson('halaman.json');
}

function getHalamanBySlug($slug) {
    $halaman = loadJson('halaman.json');
    foreach ($halaman as $h) {
        if ($h['slug'] === $slug && ($h['aktif'] ?? true)) {
            return $h;
        }
    }
    return null;
}

// Create slug
function createSlug($text) {
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    $text = preg_replace('/[\s-]+/', '-', $text);
    return trim($text, '-');
}

// Format date
function formatTanggal($date) {
    $bulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    $timestamp = strtotime($date);
    $d = date('d', $timestamp);
    $m = (int)date('m', $timestamp);
    $y = date('Y', $timestamp);
    return "$d {$bulan[$m]} $y";
}

// Reading time
function readingTime($content) {
    $word_count = str_word_count(strip_tags($content));
    $minutes = ceil($word_count / 200);
    return $minutes . ' menit baca';
}

// Generate random rating
function generateRating() {
    $setting = getSetting();
    $min = $setting['rating_min'] ?? 4.5;
    $max = $setting['rating_max'] ?? 5.0;
    return round($min + mt_rand() / mt_getrandmax() * ($max - $min), 1);
}

function generateReviewCount() {
    $setting = getSetting();
    $min = $setting['review_count_min'] ?? 5000;
    $max = $setting['review_count_max'] ?? 15000;
    return mt_rand($min, $max);
}

// Generate artikel static HTML file
function generateArtikelFile($berita) {
    $kategori = $berita['kategori'];
    $slug = $berita['slug'];
    $filepath = BASE_PATH . "/$kategori/$slug.html";

    // Create kategori folder if not exists
    if (!is_dir(BASE_PATH . "/$kategori")) {
        mkdir(BASE_PATH . "/$kategori", 0755, true);
    }

    // Generate pure static HTML
    $html = generateStaticArticleHTML($berita);
    file_put_contents($filepath, $html);
}

// Generate pure static HTML for article
function generateStaticArticleHTML($berita) {
    $setting = getSetting();
    $kategoriList = getAllKategori();
    $halamanList = getAllHalaman();

    $kategori = $berita['kategori'];
    $slug = $berita['slug'];

    // Get related articles
    $artikelTerkait = getArtikelTerkait($kategori, $berita['id'], 4);
    $beritaLainnya = getBeritaLainnya($berita['id'], 6);
    $kategoriInfo = getKategoriBySlug($kategori);

    // Sidebar data
    $beritaPopuler = getBeritaPopuler(5);
    $backlinks = loadJson('backlinks.json');
    $backlinks = array_filter($backlinks, fn($b) => $b['aktif'] ?? false);
    usort($backlinks, fn($a, $b) => ($a['urutan'] ?? 0) - ($b['urutan'] ?? 0));

    // Page meta
    $pageTitle = htmlspecialchars($berita['judul'] . ' - ' . $setting['nama_web']);
    $pageDesc = htmlspecialchars(truncate($berita['isi'], 160));
    $pageImage = htmlspecialchars($berita['gambar']);
    $pageUrl = BASE_URL . '/' . $kategori . '/' . $slug . '.html';
    $pageKeywords = !empty($berita['tags']) ? htmlspecialchars(implode(', ', $berita['tags'])) : htmlspecialchars($setting['meta_keywords']);

    // Breadcrumb items
    $breadcrumbItems = [
        ['name' => 'Home', 'url' => BASE_URL],
        ['name' => $kategoriInfo['nama'] ?? ucfirst($kategori), 'url' => BASE_URL . '/' . $kategori . '/'],
        ['name' => $berita['judul'], 'url' => $pageUrl]
    ];

    // Generate schemas
    $schemaWebsite = generateSchemaWebsite();
    $schemaArticle = generateSchemaArticle($berita);
    $schemaBreadcrumb = generateSchemaBreadcrumb($breadcrumbItems);

    // Build HTML
    $html = '<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>' . $pageTitle . '</title>
    <meta name="description" content="' . $pageDesc . '">
    <meta name="keywords" content="' . $pageKeywords . '">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:type" content="article">
    <meta property="og:title" content="' . $pageTitle . '">
    <meta property="og:description" content="' . $pageDesc . '">
    <meta property="og:image" content="' . $pageImage . '">
    <meta property="og:url" content="' . htmlspecialchars($pageUrl) . '">
    <meta property="og:site_name" content="' . htmlspecialchars($setting['nama_web']) . '">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="' . $pageTitle . '">
    <meta name="twitter:description" content="' . $pageDesc . '">
    <meta name="twitter:image" content="' . $pageImage . '">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="' . htmlspecialchars($setting['favicon']) . '">

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="' . BASE_URL . '/assets/css/style.css" rel="stylesheet">
    <link href="' . BASE_URL . '/assets/css/themes/' . ($setting['theme'] ?? 'dark-gold') . '.css" rel="stylesheet">

    <!-- Schema Website -->
    <script type="application/ld+json">
' . json_encode($schemaWebsite, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '
    </script>

    <!-- Schema Article -->
    <script type="application/ld+json">
' . json_encode($schemaArticle, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '
    </script>

    <!-- Schema Breadcrumb -->
    <script type="application/ld+json">
' . json_encode($schemaBreadcrumb, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '
    </script>

    ' . ($setting['custom_head_code'] ?? '') . '

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="' . BASE_URL . '">
                <i class="bi bi-joystick"></i> ' . htmlspecialchars($setting['nama_web']) . '
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="' . BASE_URL . '">Home</a>
                    </li>';

    // Navbar kategori
    foreach ($kategoriList as $kat) {
        $html .= '
                    <li class="nav-item">
                        <a class="nav-link" href="' . BASE_URL . '/' . $kat['id'] . '/">' . htmlspecialchars($kat['nama']) . '</a>
                    </li>';
    }

    $html .= '
                </ul>
            </div>
        </div>
    </nav>

<main class="py-4">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">';

    // Breadcrumb items
    foreach ($breadcrumbItems as $i => $item) {
        if ($i === count($breadcrumbItems) - 1) {
            $html .= '
                        <li class="breadcrumb-item active" aria-current="page">' . htmlspecialchars($item['name']) . '</li>';
        } else {
            $html .= '
                        <li class="breadcrumb-item"><a href="' . htmlspecialchars($item['url']) . '">' . htmlspecialchars($item['name']) . '</a></li>';
        }
    }

    $html .= '
                    </ol>
                </nav>

                <article class="article-content">
                    <h1 class="text-light mb-3">' . htmlspecialchars($berita['judul']) . '</h1>

                    <div class="article-meta mb-3 text-light-emphasis">
                        <span><i class="bi bi-calendar"></i> ' . formatTanggal($berita['created_at']) . '</span>
                        <span class="ms-3"><i class="bi bi-folder"></i> <a href="' . BASE_URL . '/' . $kategori . '/" class="text-warning text-decoration-none">' . htmlspecialchars($kategoriInfo['nama'] ?? ucfirst($kategori)) . '</a></span>
                        <span class="ms-3"><i class="bi bi-eye"></i> <span id="view-count">0</span> views</span>
                        <span class="ms-3"><i class="bi bi-clock"></i> ' . readingTime($berita['isi']) . '</span>
                    </div>';

    // Article image
    if (!empty($berita['gambar'])) {
        $html .= '
                    <div class="article-image mb-4">
                        <img src="' . htmlspecialchars($berita['gambar']) . '" class="img-fluid rounded" alt="' . htmlspecialchars($berita['judul']) . '">
                    </div>';
    }

    $html .= '
                    <div class="article-body text-light">
                        ' . $berita['isi'] . '
                    </div>';

    // Tags
    if (!empty($berita['tags'])) {
        $html .= '
                    <div class="article-tags mt-4">
                        <i class="bi bi-tags text-warning"></i>';
        foreach ($berita['tags'] as $tag) {
            $html .= '
                        <span class="badge bg-secondary">' . htmlspecialchars($tag) . '</span>';
        }
        $html .= '
                    </div>';
    }

    // Share buttons
    $shareUrl = urlencode($pageUrl);
    $shareTitle = urlencode($berita['judul']);
    $html .= '
                    <div class="article-share mt-4 p-3 bg-dark rounded">
                        <span class="text-warning me-2"><i class="bi bi-share"></i> Bagikan:</span>
                        <a href="https://wa.me/?text=' . $shareTitle . '%20' . $shareUrl . '" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-success">
                            <i class="bi bi-whatsapp"></i> WhatsApp
                        </a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=' . $shareUrl . '" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-primary">
                            <i class="bi bi-facebook"></i> Facebook
                        </a>
                        <a href="https://twitter.com/intent/tweet?url=' . $shareUrl . '&text=' . $shareTitle . '" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-info">
                            <i class="bi bi-twitter"></i> Twitter
                        </a>
                        <a href="https://t.me/share/url?url=' . $shareUrl . '&text=' . $shareTitle . '" target="_blank" rel="nofollow noopener" class="btn btn-sm btn-primary">
                            <i class="bi bi-telegram"></i> Telegram
                        </a>
                    </div>';

    // Berita Lainnya
    if (!empty($beritaLainnya)) {
        $html .= '
                    <div class="berita-lainnya mt-4">
                        <h5 class="text-warning mb-3"><i class="bi bi-newspaper"></i> Berita Lainnya yang Mungkin Anda Suka</h5>
                        <div class="row g-3">';
        foreach ($beritaLainnya as $bl) {
            $html .= '
                            <div class="col-md-6 col-lg-4">
                                <div class="card bg-dark border-secondary h-100 card-hover">
                                    <a href="' . BASE_URL . '/' . $bl['kategori'] . '/' . $bl['slug'] . '.html">
                                        <img src="' . htmlspecialchars($bl['gambar']) . '" class="card-img-top" alt="' . htmlspecialchars($bl['judul']) . '" style="height: 120px; object-fit: cover;">
                                    </a>
                                    <div class="card-body p-2">
                                        <a href="' . BASE_URL . '/' . $bl['kategori'] . '/' . $bl['slug'] . '.html" class="text-decoration-none">
                                            <h6 class="card-title text-light mb-1" style="font-size: 0.9rem;">' . htmlspecialchars(truncate($bl['judul'], 50)) . '</h6>
                                        </a>
                                        <small class="text-light-emphasis">
                                            <i class="bi bi-folder"></i> ' . htmlspecialchars(ucfirst($bl['kategori'])) . '
                                        </small>
                                    </div>
                                </div>
                            </div>';
        }
        $html .= '
                        </div>
                    </div>';
    }

    $html .= '
                </article>';

    // Artikel Terkait
    if (!empty($artikelTerkait)) {
        $html .= '
                <div class="artikel-terkait mt-5">
                    <h5 class="text-warning mb-3"><i class="bi bi-collection"></i> Artikel Terkait</h5>
                    <div class="row g-3">';
        foreach ($artikelTerkait as $at) {
            $html .= '
                        <div class="col-md-6 col-lg-3">
                            <div class="card bg-dark border-secondary h-100 card-hover">
                                <a href="' . BASE_URL . '/' . $at['kategori'] . '/' . $at['slug'] . '.html">
                                    <img src="' . htmlspecialchars($at['gambar']) . '" class="card-img-top" alt="' . htmlspecialchars($at['judul']) . '">
                                </a>
                                <div class="card-body">
                                    <a href="' . BASE_URL . '/' . $at['kategori'] . '/' . $at['slug'] . '.html" class="text-decoration-none">
                                        <h6 class="card-title text-light">' . htmlspecialchars($at['judul']) . '</h6>
                                    </a>
                                    <small class="text-light-emphasis">
                                        <i class="bi bi-calendar"></i> ' . formatTanggal($at['created_at']) . '
                                    </small>
                                </div>
                            </div>
                        </div>';
        }
        $html .= '
                    </div>
                </div>';
    }

    $html .= '
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <div class="sidebar">
                    <!-- 1. Search -->
                    <div class="card bg-dark border-secondary mb-4">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-search"></i> Cari Berita</h6>
                            <form action="' . BASE_URL . '/cari.php" method="GET">
                                <div class="input-group">
                                    <input type="text" name="q" class="form-control bg-secondary border-0 text-light" placeholder="Kata kunci...">
                                    <button class="btn btn-warning" type="submit"><i class="bi bi-search"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>';

    // 2. Kategori sidebar
    $html .= '
                    <div class="card bg-dark border-secondary mb-4">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-folder"></i> Kategori</h6>
                            <ul class="list-unstyled mb-0">';
    foreach ($kategoriList as $kat) {
        $html .= '
                                <li class="mb-1">
                                    <a href="' . BASE_URL . '/' . $kat['id'] . '/" class="text-light text-decoration-none">
                                        <i class="bi bi-chevron-right"></i> ' . htmlspecialchars($kat['nama']) . '
                                    </a>
                                </li>';
    }
    $html .= '
                            </ul>
                        </div>
                    </div>';

    // 3. Berita Populer
    if (!empty($beritaPopuler)) {
        $html .= '
                    <div class="card bg-dark border-secondary mb-4">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-fire"></i> Berita Populer</h6>
                            <ul class="list-unstyled mb-0">';
        foreach ($beritaPopuler as $bp) {
            $html .= '
                                <li class="mb-2 pb-2 border-bottom border-secondary">
                                    <a href="' . BASE_URL . '/' . $bp['kategori'] . '/' . $bp['slug'] . '.html" class="text-light text-decoration-none small">
                                        ' . htmlspecialchars($bp['judul']) . '
                                    </a>
                                    <div class="text-light-emphasis" style="font-size: 0.75rem;">
                                        <i class="bi bi-eye"></i> ' . number_format($bp['views'] ?? 0) . ' views
                                    </div>
                                </li>';
        }
        $html .= '
                            </ul>
                        </div>
                    </div>';
    }

    // 4. Backlinks
    if (!empty($backlinks)) {
        $html .= '
                    <div class="card bg-dark border-secondary">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-link-45deg"></i> Link Terkait</h6>
                            <ul class="list-unstyled mb-0">';
        foreach ($backlinks as $bl) {
            $html .= '
                                <li class="mb-2">
                                    <a href="' . htmlspecialchars($bl['url']) . '" class="text-warning text-decoration-none" target="_blank">
                                        <i class="bi bi-chevron-right"></i> ' . htmlspecialchars($bl['anchor']) . '
                                    </a>
                                </li>';
        }
        $html .= '
                            </ul>
                        </div>
                    </div>';
    }

    $html .= '
                </div>
            </div>
        </div>
    </div>
</main>

    <!-- Footer -->
    <footer class="mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="text-warning"><i class="bi bi-joystick"></i> ' . htmlspecialchars($setting['nama_web']) . '</h5>
                    <p class="text-light-emphasis">' . htmlspecialchars($setting['tagline']) . '</p>
                </div>
                <div class="col-md-4 mb-3">
                    <h6 class="text-warning">Kategori</h6>
                    <ul class="list-unstyled">';
    foreach ($kategoriList as $kat) {
        $html .= '
                        <li><a href="' . BASE_URL . '/' . $kat['id'] . '/" class="text-light-emphasis text-decoration-none">' . htmlspecialchars($kat['nama']) . '</a></li>';
    }
    $html .= '
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h6 class="text-warning">Halaman</h6>
                    <ul class="list-unstyled">';
    foreach ($halamanList as $hal) {
        if ($hal['aktif'] ?? true) {
            $html .= '
                        <li><a href="' . BASE_URL . '/halaman/' . $hal['slug'] . '.html" class="text-light-emphasis text-decoration-none">' . htmlspecialchars($hal['judul']) . '</a></li>';
        }
    }
    $html .= '
                    </ul>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="text-center text-light-emphasis">
                <small>&copy; ' . date('Y') . ' ' . htmlspecialchars($setting['nama_web']) . '. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="' . BASE_URL . '/assets/js/main.js"></script>

    <!-- Track View & Load Views -->
    <script>
    (function() {
        var artikelId = ' . $berita['id'] . ';
        var viewEl = document.getElementById("view-count");

        // Load current views
        fetch("' . BASE_URL . '/api/get-views.php?id=" + artikelId)
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (viewEl) viewEl.textContent = d.views.toLocaleString();
            })
            .catch(function() {});

        // Track view (hanya 1x per session)
        var tracked = sessionStorage.getItem("viewed_" + artikelId);
        if (!tracked) {
            fetch("' . BASE_URL . '/api/track-view.php?id=" + artikelId)
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    if (d.success) {
                        sessionStorage.setItem("viewed_" + artikelId, "1");
                        // Update view count +1
                        if (viewEl) {
                            var current = parseInt(viewEl.textContent.replace(/,/g, "")) || 0;
                            viewEl.textContent = (current + 1).toLocaleString();
                        }
                    }
                })
                .catch(function() {});
        }
    })();
    </script>
</body>
</html>';

    return $html;
}

// Delete artikel HTML file
function deleteArtikelFile($kategori, $slug) {
    $filepath = BASE_PATH . "/$kategori/$slug.html";

    if (file_exists($filepath)) {
        unlink($filepath);
    }
}

// Generate halaman file
function generateHalamanFile($halaman) {
    $slug = $halaman['slug'];
    $filepath = BASE_PATH . "/halaman/$slug.html";

    // Create halaman folder if not exists
    if (!is_dir(BASE_PATH . "/halaman")) {
        mkdir(BASE_PATH . "/halaman", 0755, true);
    }

    // Generate pure static HTML
    $html = generateStaticHalamanHTML($halaman);
    file_put_contents($filepath, $html);
}

// Generate pure static HTML for halaman
function generateStaticHalamanHTML($halaman) {
    $setting = getSetting();
    $kategoriList = getAllKategori();
    $halamanList = getAllHalaman();

    $slug = $halaman['slug'];

    // Sidebar data
    $beritaPopuler = getBeritaPopuler(5);
    $backlinks = loadJson('backlinks.json');
    $backlinks = array_filter($backlinks, fn($b) => $b['aktif'] ?? false);
    usort($backlinks, fn($a, $b) => ($a['urutan'] ?? 0) - ($b['urutan'] ?? 0));

    // Page meta
    $pageTitle = htmlspecialchars($halaman['judul'] . ' - ' . $setting['nama_web']);
    $pageDesc = htmlspecialchars(truncate(strip_tags($halaman['konten'] ?? $halaman['isi']), 160));
    $pageImage = htmlspecialchars($setting['og_image']);
    $pageUrl = BASE_URL . '/halaman/' . $slug . '.html';

    // Breadcrumb items
    $breadcrumbItems = [
        ['name' => 'Home', 'url' => BASE_URL],
        ['name' => $halaman['judul'], 'url' => $pageUrl]
    ];

    // Generate schemas
    $schemaWebsite = generateSchemaWebsite();
    $schemaBreadcrumb = generateSchemaBreadcrumb($breadcrumbItems);

    // Build HTML
    $html = '<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>' . $pageTitle . '</title>
    <meta name="description" content="' . $pageDesc . '">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="' . $pageTitle . '">
    <meta property="og:description" content="' . $pageDesc . '">
    <meta property="og:image" content="' . $pageImage . '">
    <meta property="og:url" content="' . htmlspecialchars($pageUrl) . '">
    <meta property="og:site_name" content="' . htmlspecialchars($setting['nama_web']) . '">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="' . $pageTitle . '">
    <meta name="twitter:description" content="' . $pageDesc . '">
    <meta name="twitter:image" content="' . $pageImage . '">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="' . htmlspecialchars($setting['favicon']) . '">

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="' . BASE_URL . '/assets/css/style.css" rel="stylesheet">
    <link href="' . BASE_URL . '/assets/css/themes/' . ($setting['theme'] ?? 'dark-gold') . '.css" rel="stylesheet">

    <!-- Schema Website -->
    <script type="application/ld+json">
' . json_encode($schemaWebsite, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '
    </script>

    <!-- Schema Breadcrumb -->
    <script type="application/ld+json">
' . json_encode($schemaBreadcrumb, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '
    </script>

    ' . ($setting['custom_head_code'] ?? '') . '

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="' . BASE_URL . '">
                <i class="bi bi-joystick"></i> ' . htmlspecialchars($setting['nama_web']) . '
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="' . BASE_URL . '">Home</a>
                    </li>';

    // Navbar kategori
    foreach ($kategoriList as $kat) {
        $html .= '
                    <li class="nav-item">
                        <a class="nav-link" href="' . BASE_URL . '/' . $kat['id'] . '/">' . htmlspecialchars($kat['nama']) . '</a>
                    </li>';
    }

    $html .= '
                </ul>
            </div>
        </div>
    </nav>

<main class="py-4">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">';

    // Breadcrumb items
    foreach ($breadcrumbItems as $i => $item) {
        if ($i === count($breadcrumbItems) - 1) {
            $html .= '
                        <li class="breadcrumb-item active" aria-current="page">' . htmlspecialchars($item['name']) . '</li>';
        } else {
            $html .= '
                        <li class="breadcrumb-item"><a href="' . htmlspecialchars($item['url']) . '">' . htmlspecialchars($item['name']) . '</a></li>';
        }
    }

    $html .= '
                    </ol>
                </nav>

                <article class="article-content">
                    <h1 class="text-light mb-4">' . htmlspecialchars($halaman['judul']) . '</h1>

                    <div class="article-body text-light">
                        ' . ($halaman['konten'] ?? $halaman['isi']) . '
                    </div>
                </article>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <div class="sidebar">
                    <!-- 1. Search -->
                    <div class="card bg-dark border-secondary mb-4">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-search"></i> Cari Berita</h6>
                            <form action="' . BASE_URL . '/cari.php" method="GET">
                                <div class="input-group">
                                    <input type="text" name="q" class="form-control bg-secondary border-0 text-light" placeholder="Kata kunci...">
                                    <button class="btn btn-warning" type="submit"><i class="bi bi-search"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>';

    // 2. Kategori sidebar
    $html .= '
                    <div class="card bg-dark border-secondary mb-4">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-folder"></i> Kategori</h6>
                            <ul class="list-unstyled mb-0">';
    foreach ($kategoriList as $kat) {
        $html .= '
                                <li class="mb-1">
                                    <a href="' . BASE_URL . '/' . $kat['id'] . '/" class="text-light text-decoration-none">
                                        <i class="bi bi-chevron-right"></i> ' . htmlspecialchars($kat['nama']) . '
                                    </a>
                                </li>';
    }
    $html .= '
                            </ul>
                        </div>
                    </div>';

    // 3. Berita Populer
    if (!empty($beritaPopuler)) {
        $html .= '
                    <div class="card bg-dark border-secondary mb-4">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-fire"></i> Berita Populer</h6>
                            <ul class="list-unstyled mb-0">';
        foreach ($beritaPopuler as $bp) {
            $html .= '
                                <li class="mb-2 pb-2 border-bottom border-secondary">
                                    <a href="' . BASE_URL . '/' . $bp['kategori'] . '/' . $bp['slug'] . '.html" class="text-light text-decoration-none small">
                                        ' . htmlspecialchars($bp['judul']) . '
                                    </a>
                                    <div class="text-light-emphasis" style="font-size: 0.75rem;">
                                        <i class="bi bi-eye"></i> ' . number_format($bp['views'] ?? 0) . ' views
                                    </div>
                                </li>';
        }
        $html .= '
                            </ul>
                        </div>
                    </div>';
    }

    // 4. Backlinks
    if (!empty($backlinks)) {
        $html .= '
                    <div class="card bg-dark border-secondary">
                        <div class="card-body">
                            <h6 class="card-title text-warning"><i class="bi bi-link-45deg"></i> Link Terkait</h6>
                            <ul class="list-unstyled mb-0">';
        foreach ($backlinks as $bl) {
            $html .= '
                                <li class="mb-2">
                                    <a href="' . htmlspecialchars($bl['url']) . '" class="text-warning text-decoration-none" target="_blank">
                                        <i class="bi bi-chevron-right"></i> ' . htmlspecialchars($bl['anchor']) . '
                                    </a>
                                </li>';
        }
        $html .= '
                            </ul>
                        </div>
                    </div>';
    }

    $html .= '
                </div>
            </div>
        </div>
    </div>
</main>

    <!-- Footer -->
    <footer class="mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="text-warning"><i class="bi bi-joystick"></i> ' . htmlspecialchars($setting['nama_web']) . '</h5>
                    <p class="text-light-emphasis">' . htmlspecialchars($setting['tagline']) . '</p>
                </div>
                <div class="col-md-4 mb-3">
                    <h6 class="text-warning">Kategori</h6>
                    <ul class="list-unstyled">';
    foreach ($kategoriList as $kat) {
        $html .= '
                        <li><a href="' . BASE_URL . '/' . $kat['id'] . '/" class="text-light-emphasis text-decoration-none">' . htmlspecialchars($kat['nama']) . '</a></li>';
    }
    $html .= '
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h6 class="text-warning">Halaman</h6>
                    <ul class="list-unstyled">';
    foreach ($halamanList as $hal) {
        if ($hal['aktif'] ?? true) {
            $html .= '
                        <li><a href="' . BASE_URL . '/halaman/' . $hal['slug'] . '.html" class="text-light-emphasis text-decoration-none">' . htmlspecialchars($hal['judul']) . '</a></li>';
        }
    }
    $html .= '
                    </ul>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="text-center text-light-emphasis">
                <small>&copy; ' . date('Y') . ' ' . htmlspecialchars($setting['nama_web']) . '. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="' . BASE_URL . '/assets/js/main.js"></script>
</body>
</html>';

    return $html;
}

// Delete halaman HTML file
function deleteHalamanFile($slug) {
    $filepath = BASE_PATH . "/halaman/$slug.html";

    if (file_exists($filepath)) {
        unlink($filepath);
    }
}

// Generate sitemap
function generateSitemap() {
    $berita = getAllBerita();
    $kategori = getAllKategori();
    $halaman = getAllHalaman();

    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    // Homepage
    $xml .= "  <url>\n";
    $xml .= "    <loc>" . BASE_URL . "/</loc>\n";
    $xml .= "    <lastmod>" . date('Y-m-d') . "</lastmod>\n";
    $xml .= "    <changefreq>daily</changefreq>\n";
    $xml .= "    <priority>1.0</priority>\n";
    $xml .= "  </url>\n";

    // Kategori
    foreach ($kategori as $k) {
        $xml .= "  <url>\n";
        $xml .= "    <loc>" . BASE_URL . "/" . $k['id'] . "/</loc>\n";
        $xml .= "    <lastmod>" . date('Y-m-d') . "</lastmod>\n";
        $xml .= "    <changefreq>daily</changefreq>\n";
        $xml .= "    <priority>0.8</priority>\n";
        $xml .= "  </url>\n";
    }

    // Berita
    foreach ($berita as $b) {
        $xml .= "  <url>\n";
        $xml .= "    <loc>" . BASE_URL . "/" . $b['kategori'] . "/" . $b['slug'] . ".html</loc>\n";
        $xml .= "    <lastmod>" . $b['created_at'] . "</lastmod>\n";
        $xml .= "    <changefreq>weekly</changefreq>\n";
        $xml .= "    <priority>0.6</priority>\n";
        $xml .= "  </url>\n";
    }

    // Halaman statis
    foreach ($halaman as $h) {
        if ($h['aktif'] ?? true) {
            $xml .= "  <url>\n";
            $xml .= "    <loc>" . BASE_URL . "/halaman/" . $h['slug'] . ".html</loc>\n";
            $xml .= "    <lastmod>" . date('Y-m-d') . "</lastmod>\n";
            $xml .= "    <changefreq>monthly</changefreq>\n";
            $xml .= "    <priority>0.4</priority>\n";
            $xml .= "  </url>\n";
        }
    }

    $xml .= '</urlset>';

    file_put_contents(BASE_PATH . '/sitemap.xml', $xml);
}

// Get article image or default
function getArticleImage($berita) {
    if (!empty($berita['gambar']) && file_exists(BASE_PATH . '/' . $berita['gambar'])) {
        return BASE_URL . '/' . $berita['gambar'];
    }
    return BASE_URL . '/assets/img/default-article.php';
}

// Truncate text
function truncate($text, $length = 150) {
    $text = strip_tags($text);
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

// Check admin login
function isLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// Verify password
function verifyPassword($password) {
    $setting = getSetting();
    return password_verify($password, $setting['admin_pass']);
}

// Upload image
function uploadImage($file, $folder = 'artikel') {
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        return ['success' => false, 'message' => 'Format file tidak diizinkan'];
    }

    $filename = time() . '_' . createSlug(pathinfo($file['name'], PATHINFO_FILENAME)) . '.' . $ext;
    $uploadPath = BASE_PATH . "/uploads/$folder/";

    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0755, true);
    }

    if (move_uploaded_file($file['tmp_name'], $uploadPath . $filename)) {
        return ['success' => true, 'filename' => "uploads/$folder/$filename"];
    }

    return ['success' => false, 'message' => 'Gagal upload file'];
}
?>
