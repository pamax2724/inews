<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/schema.php';

$setting = getSetting();
$kategoriList = getAllKategori();

// Default meta
$pageTitle = $pageTitle ?? $setting['nama_web'] . ' - ' . $setting['tagline'];
$pageDesc = $pageDesc ?? $setting['meta_desc'];
$pageImage = $pageImage ?? $setting['og_image'];
$pageUrl = $pageUrl ?? BASE_URL;
$pageKeywords = $pageKeywords ?? $setting['meta_keywords'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?= htmlspecialchars($pageTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($pageDesc) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($pageKeywords) ?>">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($pageDesc) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($pageImage) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($pageUrl) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars($setting['nama_web']) ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($pageTitle) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($pageDesc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($pageImage) ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= htmlspecialchars($setting['favicon']) ?>">

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/themes/<?= $setting['theme'] ?? 'dark-gold' ?>.css" rel="stylesheet">

    <!-- Schema Website -->
    <?php outputSchema(generateSchemaWebsite()); ?>

    <?php if (isset($schemaArticle)): ?>
    <?php outputSchema($schemaArticle); ?>
    <?php endif; ?>

    <?php if (isset($schemaBreadcrumb)): ?>
    <?php outputSchema($schemaBreadcrumb); ?>
    <?php endif; ?>

    <!-- Custom Head Code -->
    <?= $setting['custom_head_code'] ?>

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>">
                <i class="bi bi-joystick"></i> <?= htmlspecialchars($setting['nama_web']) ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>">Home</a>
                    </li>
                    <?php foreach ($kategoriList as $kat): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/<?= $kat['id'] ?>/"><?= htmlspecialchars($kat['nama']) ?></a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </nav>
