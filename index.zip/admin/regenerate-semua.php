<?php
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$message = '';
$success = false;
$details = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $artikelCount = 0;
    $halamanCount = 0;

    // Regenerate semua artikel
    $berita = getAllBerita(null, 'publish');
    foreach ($berita as $b) {
        generateArtikelFile($b);
        $artikelCount++;
    }
    $details[] = "Artikel: $artikelCount file";

    // Regenerate semua halaman
    $halaman = getAllHalaman();
    foreach ($halaman as $h) {
        if ($h['aktif'] ?? true) {
            generateHalamanFile($h);
            $halamanCount++;
        }
    }
    $details[] = "Halaman: $halamanCount file";

    // Regenerate sitemap
    generateSitemap();
    $details[] = "Sitemap: 1 file";

    $success = true;
    $message = "Berhasil regenerate semua file!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regenerate Semua - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #1a1a2e; color: #eee; }
        .card { background: #16213e; border: 1px solid #1f4068; }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-arrow-repeat"></i> Regenerate Semua File</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($message): ?>
                        <div class="alert alert-<?= $success ? 'success' : 'danger' ?>">
                            <strong><?= $message ?></strong>
                            <?php if (!empty($details)): ?>
                            <ul class="mb-0 mt-2">
                                <?php foreach ($details as $d): ?>
                                <li><?= $d ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                        <p>Klik tombol di bawah untuk regenerate:</p>
                        <ul>
                            <li>Semua artikel (HTML statis)</li>
                            <li>Semua halaman (About, Contact, dll)</li>
                            <li>Sitemap</li>
                        </ul>
                        <p class="text-warning small">Semua file akan di-generate ulang dengan tema dan setting terbaru.</p>

                        <form method="POST">
                            <button type="submit" class="btn btn-success btn-lg">
                                <i class="bi bi-arrow-clockwise"></i> Regenerate Semua
                            </button>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali
                            </a>
                        </form>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="bi bi-link-45deg"></i> Regenerate Terpisah</h6>
                    </div>
                    <div class="card-body">
                        <a href="regenerate-all.php" class="btn btn-outline-primary btn-sm me-2">
                            <i class="bi bi-newspaper"></i> Artikel Saja
                        </a>
                        <a href="regenerate-halaman.php" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-file-earmark"></i> Halaman Saja
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
