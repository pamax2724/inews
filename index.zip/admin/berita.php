<?php include 'header.php'; ?>

<?php
// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $berita = loadJson('berita.json');
    $toDelete = null;

    foreach ($berita as $key => $b) {
        if ($b['id'] == $id) {
            $toDelete = $b;
            unset($berita[$key]);
            break;
        }
    }

    if ($toDelete) {
        // Delete HTML file
        deleteArtikelFile($toDelete['kategori'], $toDelete['slug']);

        // Save updated berita
        saveJson('berita.json', array_values($berita));

        // Regenerate sitemap
        generateSitemap();
    }

    header('Location: berita.php?msg=deleted');
    exit;
}

$beritaList = loadJson('berita.json');
usort($beritaList, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));
$kategoriList = getAllKategori();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="text-warning mb-0"><i class="bi bi-newspaper"></i> Kelola Berita</h4>
    <a href="tambah.php" class="btn btn-warning">
        <i class="bi bi-plus-circle"></i> Tambah Berita
    </a>
</div>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php
    switch ($_GET['msg']) {
        case 'added': echo '<i class="bi bi-check-circle"></i> Berita berhasil ditambahkan!'; break;
        case 'updated': echo '<i class="bi bi-check-circle"></i> Berita berhasil diupdate!'; break;
        case 'deleted': echo '<i class="bi bi-check-circle"></i> Berita berhasil dihapus!'; break;
    }
    ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <?php if (empty($beritaList)): ?>
        <p class="text-secondary text-center py-4">Belum ada berita. <a href="tambah.php" class="text-warning">Tambah sekarang</a></p>
        <?php else: ?>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th width="50">Gambar</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Status</th>
                    <th>Views</th>
                    <th>Tanggal</th>
                    <th width="120">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($beritaList as $b): ?>
                <tr>
                    <td>
                        <img src="<?= htmlspecialchars($b['gambar']) ?>" width="50" height="35" style="object-fit: cover;" class="rounded">
                    </td>
                    <td>
                        <a href="<?= BASE_URL ?>/<?= $b['kategori'] ?>/<?= $b['slug'] ?>.html" target="_blank" class="text-light text-decoration-none">
                            <?= htmlspecialchars(truncate($b['judul'], 50)) ?>
                        </a>
                    </td>
                    <td><span class="badge bg-warning text-dark"><?= $b['kategori'] ?></span></td>
                    <td>
                        <?php if ($b['status'] === 'publish'): ?>
                        <span class="badge bg-success">Publish</span>
                        <?php else: ?>
                        <span class="badge bg-secondary">Draft</span>
                        <?php endif; ?>
                    </td>
                    <td><?= number_format($b['views'] ?? 0) ?></td>
                    <td><?= formatTanggal($b['created_at']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="berita.php?delete=<?= $b['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus berita ini?')" title="Hapus">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>
