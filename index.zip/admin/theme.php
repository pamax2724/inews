<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Available themes
$themes = [
    'dark-gold' => [
        'name' => 'Dark Gold',
        'description' => 'Tema gelap dengan aksen emas (Default)',
        'preview_bg' => '#121212',
        'preview_accent' => '#FFD700',
        'type' => 'dark'
    ],
    'dark-blue' => [
        'name' => 'Dark Blue (Oceanic)',
        'description' => 'Tema gelap dengan aksen biru cyan',
        'preview_bg' => '#0D1117',
        'preview_accent' => '#00D4FF',
        'type' => 'dark'
    ],
    'dark-green' => [
        'name' => 'Dark Green (Matrix)',
        'description' => 'Tema gelap dengan aksen hijau neon',
        'preview_bg' => '#0A0F0A',
        'preview_accent' => '#00FF88',
        'type' => 'dark'
    ],
    'dark-purple' => [
        'name' => 'Dark Purple (Neon)',
        'description' => 'Tema gelap dengan aksen ungu',
        'preview_bg' => '#0F0A15',
        'preview_accent' => '#A855F7',
        'type' => 'dark'
    ],
    'dark-red' => [
        'name' => 'Dark Red (Crimson)',
        'description' => 'Tema gelap dengan aksen merah',
        'preview_bg' => '#120A0A',
        'preview_accent' => '#FF4757',
        'type' => 'dark'
    ],
    'light-clean' => [
        'name' => 'Light Clean (Minimal)',
        'description' => 'Tema terang minimalis dengan aksen biru',
        'preview_bg' => '#F8FAFC',
        'preview_accent' => '#2563EB',
        'type' => 'light'
    ],
    'light-green' => [
        'name' => 'Light Green (Nature)',
        'description' => 'Tema terang dengan aksen hijau natural',
        'preview_bg' => '#F0FDF4',
        'preview_accent' => '#059669',
        'type' => 'light'
    ]
];

$setting = getSetting();
$currentTheme = $setting['theme'] ?? 'dark-gold';
$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newTheme = $_POST['theme'] ?? 'dark-gold';

    if (array_key_exists($newTheme, $themes)) {
        $setting['theme'] = $newTheme;
        saveJson('setting.json', $setting);
        $currentTheme = $newTheme;

        // Auto regenerate semua file
        $artikelCount = 0;
        $halamanCount = 0;

        // Regenerate semua artikel
        $berita = getAllBerita(null, 'publish');
        foreach ($berita as $b) {
            generateArtikelFile($b);
            $artikelCount++;
        }

        // Regenerate semua halaman
        $halamanList = getAllHalaman();
        foreach ($halamanList as $h) {
            if ($h['aktif'] ?? true) {
                generateHalamanFile($h);
                $halamanCount++;
            }
        }

        // Regenerate sitemap
        generateSitemap();

        $message = "Tema berhasil diubah ke <strong>{$themes[$newTheme]['name']}</strong>! Regenerate otomatis: $artikelCount artikel, $halamanCount halaman.";
        $messageType = 'success';
    } else {
        $message = 'Tema tidak valid!';
        $messageType = 'danger';
    }
}

include 'header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="bi bi-palette"></i> Pengaturan Tema</h2>
            </div>

            <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?> alert-dismissible fade show">
                <?= $message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="card bg-dark border-secondary">
                <div class="card-header">
                    <i class="bi bi-brush"></i> Pilih Tema Website
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="row g-4">
                            <?php foreach ($themes as $themeId => $theme): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card h-100 <?= $currentTheme === $themeId ? 'border-warning' : 'border-secondary' ?>" style="cursor: pointer;" onclick="document.getElementById('theme_<?= $themeId ?>').checked = true; this.closest('form').querySelectorAll('.card').forEach(c => c.classList.remove('border-warning')); this.classList.add('border-warning');">
                                    <div class="card-body p-0">
                                        <!-- Preview -->
                                        <div class="theme-preview" style="background-color: <?= $theme['preview_bg'] ?>; height: 120px; position: relative; border-radius: 5px 5px 0 0;">
                                            <div style="position: absolute; top: 10px; left: 10px; right: 10px; height: 20px; background-color: <?= $theme['preview_accent'] ?>20; border-radius: 3px;"></div>
                                            <div style="position: absolute; top: 40px; left: 10px; width: 60%; height: 10px; background-color: <?= $theme['preview_accent'] ?>; border-radius: 2px;"></div>
                                            <div style="position: absolute; top: 55px; left: 10px; right: 10px; height: 8px; background-color: <?= $theme['type'] === 'dark' ? '#ffffff30' : '#00000020' ?>; border-radius: 2px;"></div>
                                            <div style="position: absolute; top: 68px; left: 10px; right: 30px; height: 8px; background-color: <?= $theme['type'] === 'dark' ? '#ffffff20' : '#00000015' ?>; border-radius: 2px;"></div>
                                            <div style="position: absolute; bottom: 10px; left: 10px; padding: 5px 15px; background-color: <?= $theme['preview_accent'] ?>; border-radius: 3px;">
                                                <span style="color: <?= $theme['type'] === 'light' ? '#fff' : '#000' ?>; font-size: 10px; font-weight: bold;">BUTTON</span>
                                            </div>
                                            <?php if ($currentTheme === $themeId): ?>
                                            <div style="position: absolute; top: 5px; right: 5px;">
                                                <span class="badge bg-warning text-dark"><i class="bi bi-check-circle"></i> Aktif</span>
                                            </div>
                                            <?php endif; ?>
                                        </div>

                                        <!-- Info -->
                                        <div class="p-3" style="background-color: <?= $theme['type'] === 'dark' ? '#1a1a1a' : '#f8f9fa' ?>;">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="theme" value="<?= $themeId ?>" id="theme_<?= $themeId ?>" <?= $currentTheme === $themeId ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="theme_<?= $themeId ?>" style="color: <?= $theme['type'] === 'dark' ? '#fff' : '#333' ?>;">
                                                    <strong><?= $theme['name'] ?></strong>
                                                </label>
                                            </div>
                                            <small style="color: <?= $theme['type'] === 'dark' ? '#aaa' : '#666' ?>;"><?= $theme['description'] ?></small>

                                            <!-- Color swatches -->
                                            <div class="mt-2">
                                                <span class="d-inline-block rounded-circle me-1" style="width: 20px; height: 20px; background-color: <?= $theme['preview_bg'] ?>; border: 1px solid #555;"></span>
                                                <span class="d-inline-block rounded-circle" style="width: 20px; height: 20px; background-color: <?= $theme['preview_accent'] ?>; border: 1px solid #555;"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="mt-4 pt-3 border-top border-secondary">
                            <button type="submit" class="btn btn-warning btn-lg">
                                <i class="bi bi-check-lg"></i> Simpan Tema & Regenerate
                            </button>
                            <p class="text-muted mt-2 mb-0">
                                <i class="bi bi-info-circle"></i> Semua artikel dan halaman akan otomatis di-regenerate saat menyimpan tema.
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
