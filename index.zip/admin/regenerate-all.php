<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../includes/functions.php';

// Check login
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$berita = loadJson('berita.json');
$count = 0;
$errors = [];

foreach ($berita as $b) {
    if (isset($b['status']) && $b['status'] === 'publish') {
        try {
            generateArtikelFile($b);
            $count++;
        } catch (Exception $e) {
            $errors[] = ($b['judul'] ?? 'Unknown') . ': ' . $e->getMessage();
        } catch (Error $e) {
            $errors[] = ($b['judul'] ?? 'Unknown') . ': ' . $e->getMessage();
        }
    }
}

echo "<!DOCTYPE html><html><head><title>Regenerate All</title>";
echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">';
echo "</head><body class='bg-dark text-light p-4'>";
echo "<div class='container'>";
echo "<h2><i class='bi bi-arrow-clockwise'></i> Regenerate All Static HTML</h2>";

if ($count > 0) {
    echo "<div class='alert alert-success'><i class='bi bi-check-circle'></i> Berhasil regenerate <strong>$count</strong> artikel ke static HTML murni!</div>";
} else {
    echo "<div class='alert alert-warning'><i class='bi bi-exclamation-triangle'></i> Tidak ada artikel yang di-regenerate.</div>";
}

if (!empty($errors)) {
    echo "<div class='alert alert-danger'><strong>Errors:</strong><ul>";
    foreach ($errors as $err) {
        echo "<li>" . htmlspecialchars($err) . "</li>";
    }
    echo "</ul></div>";
}

echo "<div class='mt-3'>";
echo "<a href='berita.php' class='btn btn-primary me-2'><i class='bi bi-newspaper'></i> Daftar Berita</a>";
echo "<a href='theme.php' class='btn btn-warning'><i class='bi bi-palette'></i> Kembali ke Tema</a>";
echo "</div>";
echo "</div></body></html>";
?>
