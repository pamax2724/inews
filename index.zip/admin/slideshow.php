<?php include 'header.php'; ?>

<?php
// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $slides = loadJson('slideshow.json');

    foreach ($slides as $key => $s) {
        if ($s['id'] == $id) {
            unset($slides[$key]);
            break;
        }
    }

    saveJson('slideshow.json', array_values($slides));
    header('Location: slideshow.php?msg=deleted');
    exit;
}

// Handle add/edit
$error = '';
$editSlide = null;

if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $slides = loadJson('slideshow.json');
    foreach ($slides as $s) {
        if ($s['id'] == $editId) {
            $editSlide = $s;
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $link = trim($_POST['link'] ?? '');
    $gambar = trim($_POST['gambar'] ?? '');
    $urutan = (int)($_POST['urutan'] ?? 1);
    $aktif = isset($_POST['aktif']);
    $editId = (int)($_POST['edit_id'] ?? 0);

    if (empty($link)) {
        $error = 'Link harus diisi!';
    } elseif (empty($gambar) && $editId == 0) {
        $error = 'URL gambar harus diisi!';
    } else {
        $slides = loadJson('slideshow.json');

        // Keep existing image if editing and no new URL provided
        if ($editId > 0 && empty($gambar)) {
            foreach ($slides as $s) {
                if ($s['id'] == $editId) {
                    $gambar = $s['gambar'];
                    break;
                }
            }
        }

        if ($editId > 0) {
            // Update existing
            foreach ($slides as &$s) {
                if ($s['id'] == $editId) {
                    $s['gambar'] = $gambar;
                    $s['link'] = $link;
                    $s['urutan'] = $urutan;
                    $s['aktif'] = $aktif;
                    break;
                }
            }
        } else {
            // Add new
            $maxId = 0;
            foreach ($slides as $s) {
                if ($s['id'] > $maxId) $maxId = $s['id'];
            }

            $slides[] = [
                'id' => $maxId + 1,
                'gambar' => $gambar,
                'link' => $link,
                'urutan' => $urutan,
                'aktif' => $aktif
            ];
        }

        saveJson('slideshow.json', $slides);
        header('Location: slideshow.php?msg=' . ($editId > 0 ? 'updated' : 'added'));
        exit;
    }
}

$slides = loadJson('slideshow.json');
usort($slides, fn($a, $b) => ($a['urutan'] ?? 0) - ($b['urutan'] ?? 0));
?>

<h4 class="text-warning mb-4"><i class="bi bi-images"></i> Kelola Slideshow</h4>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php
    switch ($_GET['msg']) {
        case 'added': echo '<i class="bi bi-check-circle"></i> Slide berhasil ditambahkan!'; break;
        case 'updated': echo '<i class="bi bi-check-circle"></i> Slide berhasil diupdate!'; break;
        case 'deleted': echo '<i class="bi bi-check-circle"></i> Slide berhasil dihapus!'; break;
    }
    ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
</div>
<?php endif; ?>

<div class="row">
    <!-- Form -->
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-<?= $editSlide ? 'pencil' : 'plus-circle' ?>"></i>
                <?= $editSlide ? 'Edit Slide' : 'Tambah Slide' ?>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="edit_id" value="<?= $editSlide['id'] ?? 0 ?>">

                    <div class="mb-3">
                        <label class="form-label">URL Gambar Banner *</label>
                        <?php if ($editSlide && !empty($editSlide['gambar'])): ?>
                        <div class="mb-2">
                            <img src="<?= htmlspecialchars($editSlide['gambar']) ?>" class="img-fluid rounded">
                        </div>
                        <?php endif; ?>
                        <input type="url" name="gambar" class="form-control" placeholder="https://example.com/banner.jpg" value="<?= htmlspecialchars($editSlide['gambar'] ?? '') ?>" <?= $editSlide ? '' : 'required' ?>>
                        <?php if ($editSlide): ?>
                        <small class="text-secondary">Kosongkan jika tidak ingin mengubah</small>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Link Tujuan (nofollow) *</label>
                        <input type="url" name="link" class="form-control" required placeholder="https://example.com" value="<?= htmlspecialchars($editSlide['link'] ?? '') ?>">
                        <small class="text-secondary">Semua link otomatis rel="nofollow noopener"</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Urutan</label>
                        <input type="number" name="urutan" class="form-control" min="1" value="<?= $editSlide['urutan'] ?? 1 ?>">
                    </div>

                    <div class="mb-3 form-check">
                        <input type="checkbox" name="aktif" class="form-check-input" id="aktif" <?= ($editSlide['aktif'] ?? true) ? 'checked' : '' ?>>
                        <label class="form-check-label text-light" for="aktif">Aktif</label>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-save"></i> <?= $editSlide ? 'Update' : 'Simpan' ?>
                        </button>
                        <?php if ($editSlide): ?>
                        <a href="slideshow.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x"></i> Batal
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- List -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-list"></i> Daftar Slide
            </div>
            <div class="card-body">
                <?php if (empty($slides)): ?>
                <p class="text-secondary text-center py-4">Belum ada slide.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Preview</th>
                                <th>Link</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($slides as $s): ?>
                            <tr>
                                <td><?= $s['urutan'] ?? '-' ?></td>
                                <td>
                                    <img src="<?= htmlspecialchars($s['gambar']) ?>" height="50" class="rounded">
                                </td>
                                <td>
                                    <a href="<?= htmlspecialchars($s['link']) ?>" target="_blank" rel="nofollow noopener" class="text-warning text-decoration-none small">
                                        <?= truncate($s['link'], 40) ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($s['aktif'] ?? false): ?>
                                    <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="slideshow.php?edit=<?= $s['id'] ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="slideshow.php?delete=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus slide ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
