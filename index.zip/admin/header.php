<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../includes/functions.php';

// Check login
if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$setting = getSetting();
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?= getSetting('nama_web') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <style>
        body { background: #1a1a2e; color: #fff; }
        .sidebar {
            background: #212529;
            min-height: 100vh;
            border-right: 1px solid #ffc107;
        }
        .sidebar .nav-link {
            color: #adb5bd;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 10px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #ffc107;
            color: #000;
        }
        .sidebar .nav-link i { margin-right: 10px; }
        .content-area { padding: 20px; }
        .card { background: #212529; border: 1px solid #495057; }
        .card-header { background: #2d3238; border-bottom: 1px solid #495057; }
        .table { color: #fff; }
        .form-control, .form-select {
            background: #2d3238;
            border: 1px solid #495057;
            color: #fff;
        }
        .form-control:focus, .form-select:focus {
            background: #2d3238;
            border-color: #ffc107;
            color: #fff;
            box-shadow: 0 0 0 0.25rem rgba(255, 193, 7, 0.25);
        }
        .btn-sm { padding: 0.25rem 0.5rem; font-size: 0.8rem; }
        .form-label { color: #fff; }
        .card-header { color: #ffc107; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-3 text-center border-bottom border-secondary">
                    <i class="bi bi-joystick text-warning" style="font-size: 2rem;"></i>
                    <h6 class="text-warning mt-2 mb-0">Admin Panel</h6>
                </div>
                <nav class="nav flex-column py-3">
                    <a class="nav-link <?= $currentPage === 'dashboard' ? 'active' : '' ?>" href="dashboard.php">
                        <i class="bi bi-speedometer2"></i> Dashboard
                    </a>
                    <a class="nav-link <?= $currentPage === 'berita' || $currentPage === 'tambah' || $currentPage === 'edit' ? 'active' : '' ?>" href="berita.php">
                        <i class="bi bi-newspaper"></i> Berita
                    </a>
                    <a class="nav-link <?= $currentPage === 'kategori' ? 'active' : '' ?>" href="kategori.php">
                        <i class="bi bi-folder"></i> Kategori
                    </a>
                    <a class="nav-link <?= $currentPage === 'slideshow' ? 'active' : '' ?>" href="slideshow.php">
                        <i class="bi bi-images"></i> Slideshow
                    </a>
                    <a class="nav-link <?= $currentPage === 'halaman-admin' ? 'active' : '' ?>" href="halaman-admin.php">
                        <i class="bi bi-file-earmark-text"></i> Halaman
                    </a>
                    <a class="nav-link <?= $currentPage === 'backlink' ? 'active' : '' ?>" href="backlink.php">
                        <i class="bi bi-link-45deg"></i> Backlink
                    </a>
                    <a class="nav-link <?= $currentPage === 'theme' ? 'active' : '' ?>" href="theme.php">
                        <i class="bi bi-palette"></i> Tema
                    </a>
                    <a class="nav-link <?= $currentPage === 'setting' ? 'active' : '' ?>" href="setting.php">
                        <i class="bi bi-gear"></i> Pengaturan
                    </a>
                    <hr class="border-secondary mx-3">
                    <a class="nav-link" href="<?= BASE_URL ?>" target="_blank">
                        <i class="bi bi-box-arrow-up-right"></i> Lihat Website
                    </a>
                    <a class="nav-link text-danger" href="logout.php">
                        <i class="bi bi-box-arrow-left"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Content -->
            <div class="col-md-10 content-area">
