<?php include 'header.php'; ?>

<?php
// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $backlinks = loadJson('backlinks.json');

    foreach ($backlinks as $key => $b) {
        if ($b['id'] == $id) {
            unset($backlinks[$key]);
            break;
        }
    }

    saveJson('backlinks.json', array_values($backlinks));
    header('Location: backlink.php?msg=deleted');
    exit;
}

// Handle add/edit
$error = '';
$editBacklink = null;

if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $backlinks = loadJson('backlinks.json');
    foreach ($backlinks as $b) {
        if ($b['id'] == $editId) {
            $editBacklink = $b;
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $anchor = trim($_POST['anchor'] ?? '');
    $url = trim($_POST['url'] ?? '');
    $urutan = (int)($_POST['urutan'] ?? 1);
    $aktif = isset($_POST['aktif']);
    $editId = (int)($_POST['edit_id'] ?? 0);

    if (empty($anchor)) {
        $error = 'Anchor text harus diisi!';
    } elseif (empty($url)) {
        $error = 'URL harus diisi!';
    } else {
        $backlinks = loadJson('backlinks.json');

        if ($editId > 0) {
            // Update existing
            foreach ($backlinks as &$b) {
                if ($b['id'] == $editId) {
                    $b['anchor'] = $anchor;
                    $b['url'] = $url;
                    $b['urutan'] = $urutan;
                    $b['aktif'] = $aktif;
                    break;
                }
            }
        } else {
            // Add new
            $maxId = 0;
            foreach ($backlinks as $b) {
                if ($b['id'] > $maxId) $maxId = $b['id'];
            }

            $backlinks[] = [
                'id' => $maxId + 1,
                'anchor' => $anchor,
                'url' => $url,
                'urutan' => $urutan,
                'aktif' => $aktif
            ];
        }

        saveJson('backlinks.json', $backlinks);
        header('Location: backlink.php?msg=' . ($editId > 0 ? 'updated' : 'added'));
        exit;
    }
}

$backlinks = loadJson('backlinks.json');
usort($backlinks, fn($a, $b) => ($a['urutan'] ?? 0) - ($b['urutan'] ?? 0));
?>

<h4 class="text-warning mb-4"><i class="bi bi-link-45deg"></i> Kelola Backlink</h4>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php
    switch ($_GET['msg']) {
        case 'added': echo '<i class="bi bi-check-circle"></i> Backlink berhasil ditambahkan!'; break;
        case 'updated': echo '<i class="bi bi-check-circle"></i> Backlink berhasil diupdate!'; break;
        case 'deleted': echo '<i class="bi bi-check-circle"></i> Backlink berhasil dihapus!'; break;
    }
    ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
</div>
<?php endif; ?>

<div class="row">
    <!-- Form -->
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-<?= $editBacklink ? 'pencil' : 'plus-circle' ?>"></i>
                <?= $editBacklink ? 'Edit Backlink' : 'Tambah Backlink' ?>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="edit_id" value="<?= $editBacklink['id'] ?? 0 ?>">

                    <div class="mb-3">
                        <label class="form-label">Anchor Text *</label>
                        <input type="text" name="anchor" class="form-control" required placeholder="contoh: slot gacor" value="<?= htmlspecialchars($editBacklink['anchor'] ?? '') ?>">
                        <small class="text-secondary">Teks yang akan ditampilkan dan bisa diklik</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">URL Tujuan *</label>
                        <input type="url" name="url" class="form-control" required placeholder="https://example.com" value="<?= htmlspecialchars($editBacklink['url'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Urutan</label>
                        <input type="number" name="urutan" class="form-control" min="1" value="<?= $editBacklink['urutan'] ?? 1 ?>">
                    </div>

                    <div class="mb-3 form-check">
                        <input type="checkbox" name="aktif" class="form-check-input" id="aktif" <?= ($editBacklink['aktif'] ?? true) ? 'checked' : '' ?>>
                        <label class="form-check-label text-white" for="aktif">Aktif</label>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-save"></i> <?= $editBacklink ? 'Update' : 'Simpan' ?>
                        </button>
                        <?php if ($editBacklink): ?>
                        <a href="backlink.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x"></i> Batal
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Preview -->
        <div class="card mt-3">
            <div class="card-header">
                <i class="bi bi-eye"></i> Preview Tampilan
            </div>
            <div class="card-body bg-dark">
                <?php
                $activeLinks = array_filter($backlinks, fn($b) => $b['aktif'] ?? false);
                if (empty($activeLinks)):
                ?>
                <span class="text-secondary">Belum ada backlink aktif</span>
                <?php else: ?>
                <ul class="list-unstyled mb-0">
                    <?php foreach ($activeLinks as $bl): ?>
                    <li class="mb-2">
                        <a href="<?= htmlspecialchars($bl['url']) ?>" class="text-warning text-decoration-none" target="_blank">
                            <i class="bi bi-chevron-right"></i> <?= htmlspecialchars($bl['anchor']) ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- List -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-list"></i> Daftar Backlink
            </div>
            <div class="card-body">
                <?php if (empty($backlinks)): ?>
                <p class="text-secondary text-center py-4">Belum ada backlink.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Anchor Text</th>
                                <th>URL Tujuan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backlinks as $bl): ?>
                            <tr>
                                <td><?= $bl['urutan'] ?? '-' ?></td>
                                <td>
                                    <span class="badge bg-warning text-dark"><?= htmlspecialchars($bl['anchor']) ?></span>
                                </td>
                                <td>
                                    <a href="<?= htmlspecialchars($bl['url']) ?>" target="_blank" rel="nofollow noopener" class="text-info text-decoration-none small">
                                        <?= truncate($bl['url'], 40) ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($bl['aktif'] ?? false): ?>
                                    <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="backlink.php?edit=<?= $bl['id'] ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="backlink.php?delete=<?= $bl['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus backlink ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
