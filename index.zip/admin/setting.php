<?php
session_start();
require_once '../includes/functions.php';

// Check login
if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $setting = loadJson('setting.json');

    // Basic settings
    $setting['nama_web'] = trim($_POST['nama_web'] ?? '');
    $setting['meta_title'] = trim($_POST['meta_title'] ?? '');
    $setting['tagline'] = trim($_POST['tagline'] ?? '');
    $setting['deskripsi'] = trim($_POST['deskripsi'] ?? '');
    $setting['meta_keywords'] = trim($_POST['keywords'] ?? '');
    $setting['email'] = trim($_POST['email'] ?? '');
    $setting['custom_head_code'] = $_POST['custom_head_code'] ?? '';
    $setting['custom_footer_code'] = $_POST['custom_footer_code'] ?? '';

    // Rating settings
    $setting['rating_min'] = (float)($_POST['rating_min'] ?? 4.0);
    $setting['rating_max'] = (float)($_POST['rating_max'] ?? 5.0);
    $setting['review_count_min'] = (int)($_POST['review_count_min'] ?? 100);
    $setting['review_count_max'] = (int)($_POST['review_count_max'] ?? 500);

    // Social media
    $setting['sosmed'] = [
        'facebook' => trim($_POST['facebook'] ?? ''),
        'twitter' => trim($_POST['twitter'] ?? ''),
        'instagram' => trim($_POST['instagram'] ?? ''),
        'youtube' => trim($_POST['youtube'] ?? ''),
        'tiktok' => trim($_POST['tiktok'] ?? '')
    ];

    // Handle image URLs
    $setting['logo'] = trim($_POST['logo'] ?? '');
    $setting['favicon'] = trim($_POST['favicon'] ?? '');
    $setting['og_image'] = trim($_POST['og_image'] ?? '');

    if (empty($error)) {
        saveJson('setting.json', $setting);
        header('Location: setting.php?msg=saved');
        exit;
    }
}

$setting = loadJson('setting.json');

include 'header.php';
?>

<h4 class="text-warning mb-4"><i class="bi bi-gear"></i> Pengaturan Website</h4>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'saved'): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle"></i> Pengaturan berhasil disimpan!
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
</div>
<?php endif; ?>

<form method="POST">
    <div class="row">
        <!-- Basic Settings -->
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-info-circle"></i> Informasi Dasar
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Website</label>
                        <input type="text" name="nama_web" class="form-control" value="<?= htmlspecialchars($setting['nama_web'] ?? '') ?>">
                        <small class="text-secondary">Nama pendek untuk navbar/header</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Meta Title (Title Tag)</label>
                        <input type="text" name="meta_title" class="form-control" value="<?= htmlspecialchars($setting['meta_title'] ?? '') ?>">
                        <small class="text-secondary">Judul yang muncul di tab browser & hasil pencarian Google</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tagline</label>
                        <input type="text" name="tagline" class="form-control" value="<?= htmlspecialchars($setting['tagline'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Deskripsi (Meta Description)</label>
                        <textarea name="deskripsi" class="form-control" rows="3"><?= htmlspecialchars($setting['deskripsi'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Keywords (pisahkan dengan koma)</label>
                        <input type="text" name="keywords" class="form-control" value="<?= htmlspecialchars($setting['meta_keywords'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($setting['email'] ?? '') ?>">
                    </div>
                </div>
            </div>

            <!-- Social Media -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-share"></i> Sosial Media
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-facebook"></i> Facebook</label>
                        <input type="url" name="facebook" class="form-control" placeholder="https://facebook.com/..." value="<?= htmlspecialchars($setting['sosmed']['facebook'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-twitter-x"></i> Twitter/X</label>
                        <input type="url" name="twitter" class="form-control" placeholder="https://twitter.com/..." value="<?= htmlspecialchars($setting['sosmed']['twitter'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-instagram"></i> Instagram</label>
                        <input type="url" name="instagram" class="form-control" placeholder="https://instagram.com/..." value="<?= htmlspecialchars($setting['sosmed']['instagram'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-youtube"></i> YouTube</label>
                        <input type="url" name="youtube" class="form-control" placeholder="https://youtube.com/..." value="<?= htmlspecialchars($setting['sosmed']['youtube'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-tiktok"></i> TikTok</label>
                        <input type="url" name="tiktok" class="form-control" placeholder="https://tiktok.com/..." value="<?= htmlspecialchars($setting['sosmed']['tiktok'] ?? '') ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-md-6">
            <!-- Images -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-image"></i> Gambar
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Logo (URL)</label>
                        <?php if (!empty($setting['logo'])): ?>
                        <div class="mb-2">
                            <img src="<?= htmlspecialchars($setting['logo']) ?>" height="50" class="bg-light p-2 rounded">
                        </div>
                        <?php endif; ?>
                        <input type="url" name="logo" class="form-control" placeholder="https://example.com/logo.png" value="<?= htmlspecialchars($setting['logo'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Favicon (URL)</label>
                        <?php if (!empty($setting['favicon'])): ?>
                        <div class="mb-2">
                            <img src="<?= htmlspecialchars($setting['favicon']) ?>" height="32" class="bg-light p-1 rounded">
                        </div>
                        <?php endif; ?>
                        <input type="url" name="favicon" class="form-control" placeholder="https://example.com/favicon.png" value="<?= htmlspecialchars($setting['favicon'] ?? '') ?>">
                        <small class="text-secondary">Ukuran ideal: 32x32 atau 64x64</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Default OG Image (URL)</label>
                        <?php if (!empty($setting['og_image'])): ?>
                        <div class="mb-2">
                            <img src="<?= htmlspecialchars($setting['og_image']) ?>" height="80" class="rounded">
                        </div>
                        <?php endif; ?>
                        <input type="url" name="og_image" class="form-control" placeholder="https://example.com/og-image.jpg" value="<?= htmlspecialchars($setting['og_image'] ?? '') ?>">
                        <small class="text-secondary">Gambar untuk share sosial media. Ukuran ideal: 1200x630</small>
                    </div>
                </div>
            </div>

            <!-- Rating Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-star"></i> Pengaturan Rating (Schema)
                </div>
                <div class="card-body">
                    <p class="text-secondary small mb-3">Rating akan digenerate secara random dalam rentang ini untuk setiap artikel.</p>

                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Rating Min</label>
                                <input type="number" name="rating_min" class="form-control" step="0.1" min="1" max="5" value="<?= $setting['rating_min'] ?? 4.0 ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Rating Max</label>
                                <input type="number" name="rating_max" class="form-control" step="0.1" min="1" max="5" value="<?= $setting['rating_max'] ?? 5.0 ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Review Count Min</label>
                                <input type="number" name="review_count_min" class="form-control" min="1" value="<?= $setting['review_count_min'] ?? 100 ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Review Count Max</label>
                                <input type="number" name="review_count_max" class="form-control" min="1" value="<?= $setting['review_count_max'] ?? 500 ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Custom Code -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-code-slash"></i> Custom Code
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Kode Sebelum &lt;/head&gt;</label>
                        <textarea name="custom_head_code" class="form-control font-monospace" rows="5" placeholder="<!-- Google Analytics, Facebook Pixel, dll -->"><?= htmlspecialchars($setting['custom_head_code'] ?? '') ?></textarea>
                        <small class="text-secondary">Untuk tracking code, meta tag tambahan, CSS kustom, dll.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Kode Sebelum &lt;/body&gt;</label>
                        <textarea name="custom_footer_code" class="form-control font-monospace" rows="5" placeholder="<!-- Script tambahan -->"><?= htmlspecialchars($setting['custom_footer_code'] ?? '') ?></textarea>
                        <small class="text-secondary">Untuk script tambahan di bagian bawah halaman.</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="mb-4">
        <button type="submit" class="btn btn-warning btn-lg">
            <i class="bi bi-save"></i> Simpan Pengaturan
        </button>
    </div>
</form>

<?php include 'footer.php'; ?>
