<?php
require_once 'header.php';

$kategori = loadJson('kategori.json');
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'tambah') {
        $id = createSlug($_POST['nama']);
        $nama = trim($_POST['nama']);
        $deskripsi = trim($_POST['deskripsi']);

        // Check if ID already exists
        $exists = false;
        foreach ($kategori as $k) {
            if ($k['id'] === $id) {
                $exists = true;
                break;
            }
        }

        if (empty($nama)) {
            $error = 'Nama kategori tidak boleh kosong!';
        } elseif ($exists) {
            $error = 'Kategori dengan nama tersebut sudah ada!';
        } else {
            $kategori[] = [
                'id' => $id,
                'nama' => $nama,
                'deskripsi' => $deskripsi
            ];
            saveJson('kategori.json', $kategori);

            // Create folder for kategori if not exists
            $folderPath = BASE_PATH . '/' . $id;
            if (!is_dir($folderPath)) {
                mkdir($folderPath, 0755, true);
            }

            // Create index.php for kategori
            generateKategoriIndex($id);

            $message = 'Kategori berhasil ditambahkan!';
        }
    }

    elseif ($action === 'edit') {
        $oldId = $_POST['old_id'];
        $nama = trim($_POST['nama']);
        $deskripsi = trim($_POST['deskripsi']);
        $newId = createSlug($nama);

        if (empty($nama)) {
            $error = 'Nama kategori tidak boleh kosong!';
        } else {
            // Check if new ID conflicts with another kategori
            $conflict = false;
            foreach ($kategori as $k) {
                if ($k['id'] === $newId && $k['id'] !== $oldId) {
                    $conflict = true;
                    break;
                }
            }

            if ($conflict) {
                $error = 'Kategori dengan nama tersebut sudah ada!';
            } else {
                // Update kategori
                foreach ($kategori as &$k) {
                    if ($k['id'] === $oldId) {
                        $k['id'] = $newId;
                        $k['nama'] = $nama;
                        $k['deskripsi'] = $deskripsi;
                        break;
                    }
                }
                saveJson('kategori.json', $kategori);

                // If ID changed, update all berita and rename folder
                if ($oldId !== $newId) {
                    // Update berita.json
                    $berita = loadJson('berita.json');
                    foreach ($berita as &$b) {
                        if ($b['kategori'] === $oldId) {
                            $b['kategori'] = $newId;
                        }
                    }
                    saveJson('berita.json', $berita);

                    // Rename folder
                    $oldFolder = BASE_PATH . '/' . $oldId;
                    $newFolder = BASE_PATH . '/' . $newId;
                    if (is_dir($oldFolder) && !is_dir($newFolder)) {
                        rename($oldFolder, $newFolder);
                    }
                }

                // Regenerate kategori index
                generateKategoriIndex($newId);

                $message = 'Kategori berhasil diupdate!';
            }
        }
    }

    elseif ($action === 'hapus') {
        $id = $_POST['id'];

        // Check if kategori has berita
        $berita = loadJson('berita.json');
        $hasBerita = false;
        foreach ($berita as $b) {
            if ($b['kategori'] === $id) {
                $hasBerita = true;
                break;
            }
        }

        if ($hasBerita) {
            $error = 'Tidak dapat menghapus kategori yang masih memiliki berita!';
        } else {
            // Remove kategori
            $kategori = array_filter($kategori, fn($k) => $k['id'] !== $id);
            $kategori = array_values($kategori);
            saveJson('kategori.json', $kategori);

            // Delete folder if empty
            $folderPath = BASE_PATH . '/' . $id;
            if (is_dir($folderPath)) {
                $files = glob($folderPath . '/*');
                if (empty($files)) {
                    rmdir($folderPath);
                }
            }

            $message = 'Kategori berhasil dihapus!';
        }
    }

    // Reload kategori after changes
    $kategori = loadJson('kategori.json');
}

// Function to generate kategori index page
function generateKategoriIndex($kategoriId) {
    $filepath = BASE_PATH . '/' . $kategoriId . '/index.php';
    $content = '<?php
require_once \'../includes/functions.php\';

$kategori = getKategoriBySlug(\'' . $kategoriId . '\');
if (!$kategori) {
    header(\'Location: \' . BASE_URL);
    exit;
}

$beritaList = getBeritaByKategori(\'' . $kategoriId . '\');
$kategoriList = getAllKategori();

$pageTitle = $kategori[\'nama\'] . \' - \' . getSetting(\'nama_web\');
$pageDesc = $kategori[\'deskripsi\'];
$pageUrl = BASE_URL . \'/' . $kategoriId . '/\';

include \'../includes/header.php\';
?>

<main class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <h4 class="text-warning mb-3"><i class="bi bi-folder"></i> <?= htmlspecialchars($kategori[\'nama\']) ?></h4>
                <p class="text-light-emphasis mb-4"><?= htmlspecialchars($kategori[\'deskripsi\']) ?></p>

                <?php if (empty($beritaList)): ?>
                <div class="alert alert-secondary">
                    <i class="bi bi-info-circle"></i> Belum ada berita di kategori ini.
                </div>
                <?php else: ?>
                    <?php foreach ($beritaList as $berita): ?>
                    <div class="card bg-dark border-secondary mb-3" style="overflow:hidden;">
                        <div class="row g-0">
                            <div class="col-4">
                                <a href="<?= BASE_URL ?>/<?= $berita[\'kategori\'] ?>/<?= $berita[\'slug\'] ?>.html">
                                    <img src="<?= htmlspecialchars($berita[\'gambar\']) ?>" style="width:100%; height:130px; object-fit:cover;" alt="<?= htmlspecialchars($berita[\'judul\']) ?>">
                                </a>
                            </div>
                            <div class="col-8">
                                <div class="card-body py-2 px-3">
                                    <a href="<?= BASE_URL ?>/<?= $berita[\'kategori\'] ?>/<?= $berita[\'slug\'] ?>.html" class="text-decoration-none">
                                        <h6 class="card-title text-light mb-1" style="font-size:0.95rem;"><?= htmlspecialchars($berita[\'judul\']) ?></h6>
                                    </a>
                                    <p class="card-text text-secondary mb-1" style="font-size:0.8rem;"><?= truncate($berita[\'isi\'], 80) ?></p>
                                    <small class="text-secondary" style="font-size:0.75rem;">
                                        <i class="bi bi-calendar"></i> <?= formatTanggal($berita[\'created_at\']) ?>
                                        <span class="ms-2"><i class="bi bi-eye"></i> <?= number_format($berita[\'views\'] ?? 0) ?></span>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="col-lg-4">
                <?php include \'../includes/sidebar.php\'; ?>
            </div>
        </div>
    </div>
</main>

<?php include \'../includes/footer.php\'; ?>
';

    // Create folder if not exists
    $folderPath = BASE_PATH . '/' . $kategoriId;
    if (!is_dir($folderPath)) {
        mkdir($folderPath, 0755, true);
    }

    file_put_contents($filepath, $content);
}
?>

<h4 class="text-warning mb-4"><i class="bi bi-folder"></i> Kelola Kategori</h4>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="bi bi-check-circle"></i> <?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <!-- Form Tambah -->
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-plus-circle"></i> Tambah Kategori Baru
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="tambah">
                    <div class="mb-3">
                        <label class="form-label">Nama Kategori</label>
                        <input type="text" name="nama" class="form-control" required placeholder="Contoh: Tutorial">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="3" placeholder="Deskripsi singkat kategori"></textarea>
                    </div>
                    <button type="submit" class="btn btn-warning w-100">
                        <i class="bi bi-plus-circle"></i> Tambah Kategori
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Daftar Kategori -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-list"></i> Daftar Kategori</span>
                <span class="badge bg-warning text-dark"><?= count($kategori) ?> Kategori</span>
            </div>
            <div class="card-body">
                <?php if (empty($kategori)): ?>
                <div class="alert alert-secondary mb-0">
                    <i class="bi bi-info-circle"></i> Belum ada kategori. Tambahkan kategori baru di form sebelah.
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th width="30">#</th>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Deskripsi</th>
                                <th>Jumlah Berita</th>
                                <th width="150">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $beritaAll = loadJson('berita.json');
                            foreach ($kategori as $i => $k):
                                $jumlahBerita = count(array_filter($beritaAll, fn($b) => $b['kategori'] === $k['id']));
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><code><?= htmlspecialchars($k['id']) ?></code></td>
                                <td><?= htmlspecialchars($k['nama']) ?></td>
                                <td class="text-light-emphasis small"><?= htmlspecialchars(truncate($k['deskripsi'] ?? '', 50)) ?></td>
                                <td>
                                    <span class="badge bg-secondary"><?= $jumlahBerita ?> Berita</span>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-warning"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editModal<?= $i ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php if ($jumlahBerita == 0): ?>
                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                            data-bs-toggle="modal"
                                            data-bs-target="#hapusModal<?= $i ?>">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php else: ?>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" disabled title="Tidak bisa dihapus, masih ada berita">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                    <a href="<?= BASE_URL ?>/<?= $k['id'] ?>/" target="_blank" class="btn btn-sm btn-outline-info">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editModal<?= $i ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content bg-dark">
                                        <div class="modal-header border-secondary">
                                            <h5 class="modal-title text-warning"><i class="bi bi-pencil"></i> Edit Kategori</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="action" value="edit">
                                                <input type="hidden" name="old_id" value="<?= $k['id'] ?>">
                                                <div class="mb-3">
                                                    <label class="form-label">Nama Kategori</label>
                                                    <input type="text" name="nama" class="form-control" required value="<?= htmlspecialchars($k['nama']) ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Deskripsi</label>
                                                    <textarea name="deskripsi" class="form-control" rows="3"><?= htmlspecialchars($k['deskripsi'] ?? '') ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-secondary">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-warning">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Hapus Modal -->
                            <div class="modal fade" id="hapusModal<?= $i ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content bg-dark">
                                        <div class="modal-header border-secondary">
                                            <h5 class="modal-title text-danger"><i class="bi bi-exclamation-triangle"></i> Hapus Kategori</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Apakah Anda yakin ingin menghapus kategori <strong class="text-warning"><?= htmlspecialchars($k['nama']) ?></strong>?</p>
                                            <p class="text-light-emphasis small">Tindakan ini tidak dapat dibatalkan.</p>
                                        </div>
                                        <div class="modal-footer border-secondary">
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="action" value="hapus">
                                                <input type="hidden" name="id" value="<?= $k['id'] ?>">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
