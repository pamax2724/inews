<?php include 'header.php'; ?>

<?php
$totalBerita = count(loadJson('berita.json'));
$totalPublish = count(array_filter(loadJson('berita.json'), fn($b) => $b['status'] === 'publish'));
$totalDraft = count(array_filter(loadJson('berita.json'), fn($b) => $b['status'] === 'draft'));
$totalSlide = count(loadJson('slideshow.json'));
$totalHalaman = count(loadJson('halaman.json'));
$beritaTerbaru = getAllBerita(5);
?>

<h4 class="text-warning mb-4"><i class="bi bi-speedometer2"></i> Dashboard</h4>

<!-- Stats -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <i class="bi bi-newspaper text-warning" style="font-size: 2rem;"></i>
                <h3 class="mt-2 text-white"><?= $totalBerita ?></h3>
                <p class="text-light mb-0">Total Berita</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <i class="bi bi-check-circle text-success" style="font-size: 2rem;"></i>
                <h3 class="mt-2 text-white"><?= $totalPublish ?></h3>
                <p class="text-light mb-0">Published</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <i class="bi bi-pencil text-info" style="font-size: 2rem;"></i>
                <h3 class="mt-2 text-white"><?= $totalDraft ?></h3>
                <p class="text-light mb-0">Draft</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <i class="bi bi-images text-primary" style="font-size: 2rem;"></i>
                <h3 class="mt-2 text-white"><?= $totalSlide ?></h3>
                <p class="text-light mb-0">Slideshow</p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-lightning"></i> Aksi Cepat
            </div>
            <div class="card-body">
                <a href="tambah.php" class="btn btn-warning me-2">
                    <i class="bi bi-plus-circle"></i> Tambah Berita
                </a>
                <a href="slideshow.php" class="btn btn-outline-warning me-2">
                    <i class="bi bi-images"></i> Kelola Slideshow
                </a>
                <a href="setting.php" class="btn btn-outline-secondary">
                    <i class="bi bi-gear"></i> Pengaturan
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-info-circle"></i> Informasi
            </div>
            <div class="card-body text-white">
                <p class="mb-1"><strong>Website:</strong> <?= getSetting('nama_web') ?></p>
                <p class="mb-1"><strong>URL:</strong> <a href="<?= BASE_URL ?>" target="_blank" class="text-warning"><?= BASE_URL ?></a></p>
                <p class="mb-0"><strong>Tanggal:</strong> <?= formatTanggal(date('Y-m-d')) ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Berita Terbaru -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-newspaper"></i> Berita Terbaru</span>
        <a href="berita.php" class="btn btn-sm btn-warning">Lihat Semua</a>
    </div>
    <div class="card-body">
        <?php if (empty($beritaTerbaru)): ?>
        <p class="text-secondary">Belum ada berita.</p>
        <?php else: ?>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Views</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($beritaTerbaru as $b): ?>
                <tr>
                    <td><?= htmlspecialchars(truncate($b['judul'], 50)) ?></td>
                    <td><span class="badge bg-warning text-dark"><?= $b['kategori'] ?></span></td>
                    <td><?= number_format($b['views'] ?? 0) ?></td>
                    <td><?= formatTanggal($b['created_at']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-warning">
                            <i class="bi bi-pencil"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>
