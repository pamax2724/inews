<?php include 'header.php'; ?>

<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$berita = getBeritaById($id);

if (!$berita) {
    header('Location: berita.php');
    exit;
}

$kategoriList = getAllKategori();
$error = '';
$oldKategori = $berita['kategori'];
$oldSlug = $berita['slug'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $kategori = $_POST['kategori'] ?? '';
    $isi = $_POST['isi'] ?? '';
    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'] ?? '')));
    $status = $_POST['status'] ?? 'draft';

    // Get image URL
    $gambar = trim($_POST['gambar'] ?? $berita['gambar']);

    // Validation
    if (empty($judul) || empty($kategori) || empty($isi)) {
        $error = 'Judul, kategori, dan isi harus diisi!';
    } else {
        if (empty($error)) {
            $allBerita = loadJson('berita.json');

            // Create new slug if title changed
            $slug = $berita['slug'];
            if ($judul !== $berita['judul'] || $kategori !== $berita['kategori']) {
                $slug = createSlug($judul);

                // Check duplicate slug
                foreach ($allBerita as $b) {
                    if ($b['id'] != $id && $b['kategori'] === $kategori && $b['slug'] === $slug) {
                        $slug .= '-' . $id;
                        break;
                    }
                }
            }

            // Update berita
            foreach ($allBerita as &$b) {
                if ($b['id'] == $id) {
                    $b['judul'] = $judul;
                    $b['slug'] = $slug;
                    $b['isi'] = $isi;
                    $b['gambar'] = $gambar;
                    $b['kategori'] = $kategori;
                    $b['tags'] = $tags;
                    $b['status'] = $status;
                    $b['updated_at'] = date('Y-m-d H:i:s');
                    break;
                }
            }

            saveJson('berita.json', $allBerita);

            // Delete old HTML file if kategori or slug changed
            if ($oldKategori !== $kategori || $oldSlug !== $slug) {
                deleteArtikelFile($oldKategori, $oldSlug);
            }

            // Generate/update HTML file if published
            if ($status === 'publish') {
                // Get updated berita data
                $updatedBerita = getBeritaById($id);
                if ($updatedBerita) {
                    generateArtikelFile($updatedBerita);
                }
            } else {
                // Delete HTML file if unpublished
                deleteArtikelFile($kategori, $slug);
            }

            generateSitemap();

            header('Location: berita.php?msg=updated');
            exit;
        }
    }
}

$tagsString = is_array($berita['tags']) ? implode(', ', $berita['tags']) : '';
?>

<h4 class="text-warning mb-4"><i class="bi bi-pencil"></i> Edit Berita</h4>

<?php if ($error): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <form method="POST">
            <div class="row">
                <div class="col-md-8">
                    <div class="mb-3">
                        <label class="form-label">Judul Berita *</label>
                        <input type="text" name="judul" class="form-control" required value="<?= htmlspecialchars($berita['judul']) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Isi Berita *</label>
                        <textarea name="isi" class="form-control summernote"><?= htmlspecialchars($berita['isi']) ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tags (pisahkan dengan koma)</label>
                        <input type="text" name="tags" class="form-control" placeholder="pragmatic, maxwin, gacor" value="<?= htmlspecialchars($tagsString) ?>">
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori" class="form-select" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($kategoriList as $kat): ?>
                            <option value="<?= $kat['id'] ?>" <?= $berita['kategori'] === $kat['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($kat['nama']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Gambar (OG Image)</label>
                        <?php if (!empty($berita['gambar'])): ?>
                        <div class="mb-2">
                            <img src="<?= htmlspecialchars($berita['gambar']) ?>" class="img-fluid rounded" style="max-height: 150px;">
                        </div>
                        <?php endif; ?>
                        <input type="url" name="gambar" class="form-control" placeholder="https://example.com/gambar.jpg" value="<?= htmlspecialchars($berita['gambar']) ?>">
                        <small class="text-secondary">Masukkan URL gambar</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= $berita['status'] === 'draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="publish" <?= $berita['status'] === 'publish' ? 'selected' : '' ?>>Publish</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-secondary">Info</label>
                        <p class="small text-secondary mb-1">Views: <?= number_format($berita['views'] ?? 0) ?></p>
                        <p class="small text-secondary mb-1">Rating: <?= $berita['rating'] ?? '-' ?> (<?= number_format($berita['review_count'] ?? 0) ?> reviews)</p>
                        <p class="small text-secondary mb-0">Dibuat: <?= formatTanggal($berita['created_at']) ?></p>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-save"></i> Update Berita
                        </button>
                        <a href="<?= BASE_URL ?>/<?= $berita['kategori'] ?>/<?= $berita['slug'] ?>.html" target="_blank" class="btn btn-outline-info">
                            <i class="bi bi-eye"></i> Lihat Artikel
                        </a>
                        <a href="berita.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
