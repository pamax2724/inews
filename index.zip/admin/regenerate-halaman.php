<?php
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $halaman = getAllHalaman();
    $count = 0;

    foreach ($halaman as $h) {
        if ($h['aktif'] ?? true) {
            generateHalamanFile($h);
            $count++;
        }
    }

    $success = true;
    $message = "Berhasil regenerate $count halaman statis.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regenerate Halaman - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #1a1a2e; color: #eee; }
        .card { background: #16213e; border: 1px solid #1f4068; }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-file-earmark-code"></i> Regenerate Halaman Statis</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($message): ?>
                        <div class="alert alert-<?= $success ? 'success' : 'danger' ?>">
                            <?= $message ?>
                        </div>
                        <?php endif; ?>

                        <p>Klik tombol di bawah untuk regenerate semua halaman statis (About, Contact, Disclaimer, Privacy Policy).</p>
                        <p class="text-warning small">Halaman akan di-generate ulang dengan tema dan setting terbaru.</p>

                        <form method="POST">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-arrow-clockwise"></i> Regenerate Semua Halaman
                            </button>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali
                            </a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
