<?php include 'header.php'; ?>

<?php
// Handle delete
if (isset($_GET['delete'])) {
    $slug = basename($_GET['delete']);
    $halaman = loadJson('halaman.json');

    foreach ($halaman as $key => $h) {
        if ($h['slug'] == $slug) {
            unset($halaman[$key]);
            break;
        }
    }

    // Delete the .html file
    $filePath = dirname(__DIR__) . '/halaman/' . $slug . '.html';
    if (file_exists($filePath)) {
        unlink($filePath);
    }

    saveJson('halaman.json', array_values($halaman));
    header('Location: halaman-admin.php?msg=deleted');
    exit;
}

// Handle add/edit
$error = '';
$editHalaman = null;

if (isset($_GET['edit'])) {
    $editSlug = basename($_GET['edit']);
    $halaman = loadJson('halaman.json');
    foreach ($halaman as $h) {
        if ($h['slug'] == $editSlug) {
            $editHalaman = $h;
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $konten = $_POST['konten'] ?? '';
    $editSlug = trim($_POST['edit_slug'] ?? '');
    $newSlug = trim($_POST['slug'] ?? '');

    if (empty($judul)) {
        $error = 'Judul harus diisi!';
    } elseif (empty($newSlug)) {
        $error = 'Slug harus diisi!';
    } elseif (empty($konten)) {
        $error = 'Konten harus diisi!';
    } else {
        // Sanitize slug
        $newSlug = preg_replace('/[^a-z0-9\-]/', '', strtolower($newSlug));

        $halaman = loadJson('halaman.json');

        // Check if slug already exists (for new pages)
        if (empty($editSlug)) {
            foreach ($halaman as $h) {
                if ($h['slug'] == $newSlug) {
                    $error = 'Slug sudah digunakan!';
                    break;
                }
            }
        }

        if (empty($error)) {
            if (!empty($editSlug)) {
                // Update existing
                foreach ($halaman as &$h) {
                    if ($h['slug'] == $editSlug) {
                        // If slug changed, delete old file
                        if ($editSlug != $newSlug) {
                            $oldFile = dirname(__DIR__) . '/halaman/' . $editSlug . '.html';
                            if (file_exists($oldFile)) {
                                unlink($oldFile);
                            }
                        }

                        $h['judul'] = $judul;
                        $h['slug'] = $newSlug;
                        $h['konten'] = $konten;
                        $h['updated_at'] = date('Y-m-d H:i:s');
                        break;
                    }
                }
            } else {
                // Add new
                $halaman[] = [
                    'judul' => $judul,
                    'slug' => $newSlug,
                    'konten' => $konten,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
            }

            saveJson('halaman.json', $halaman);

            // Generate static HTML file
            $updatedHalaman = null;
            foreach ($halaman as $h) {
                if ($h['slug'] == $newSlug) {
                    $updatedHalaman = $h;
                    break;
                }
            }

            if ($updatedHalaman) {
                generateHalamanFile($updatedHalaman);
            }

            header('Location: halaman-admin.php?msg=' . (!empty($editSlug) ? 'updated' : 'added'));
            exit;
        }
    }
}

$halaman = loadJson('halaman.json');
?>

<h4 class="text-warning mb-4"><i class="bi bi-file-earmark-text"></i> Kelola Halaman Statis</h4>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php
    switch ($_GET['msg']) {
        case 'added': echo '<i class="bi bi-check-circle"></i> Halaman berhasil ditambahkan!'; break;
        case 'updated': echo '<i class="bi bi-check-circle"></i> Halaman berhasil diupdate!'; break;
        case 'deleted': echo '<i class="bi bi-check-circle"></i> Halaman berhasil dihapus!'; break;
    }
    ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
</div>
<?php endif; ?>

<div class="row">
    <!-- Form -->
    <div class="col-md-5">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-<?= $editHalaman ? 'pencil' : 'plus-circle' ?>"></i>
                <?= $editHalaman ? 'Edit Halaman' : 'Tambah Halaman' ?>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="edit_slug" value="<?= htmlspecialchars($editHalaman['slug'] ?? '') ?>">

                    <div class="mb-3">
                        <label class="form-label">Judul Halaman *</label>
                        <input type="text" name="judul" class="form-control" required value="<?= htmlspecialchars($editHalaman['judul'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Slug *</label>
                        <div class="input-group">
                            <span class="input-group-text">/halaman/</span>
                            <input type="text" name="slug" class="form-control" required placeholder="about-us" value="<?= htmlspecialchars($editHalaman['slug'] ?? '') ?>">
                            <span class="input-group-text">.html</span>
                        </div>
                        <small class="text-secondary">Hanya huruf kecil, angka, dan strip (-)</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Konten *</label>
                        <textarea name="konten" class="form-control summernote" rows="10"><?= htmlspecialchars($editHalaman['konten'] ?? '') ?></textarea>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-save"></i> <?= $editHalaman ? 'Update' : 'Simpan' ?>
                        </button>
                        <?php if ($editHalaman): ?>
                        <a href="halaman-admin.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x"></i> Batal
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- List -->
    <div class="col-md-7">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-list"></i> Daftar Halaman
            </div>
            <div class="card-body">
                <?php if (empty($halaman)): ?>
                <p class="text-secondary text-center py-4">Belum ada halaman.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>Judul</th>
                                <th>URL</th>
                                <th>Updated</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($halaman as $h): ?>
                            <tr>
                                <td><?= htmlspecialchars($h['judul']) ?></td>
                                <td>
                                    <a href="<?= BASE_URL ?>/halaman/<?= $h['slug'] ?>.html" target="_blank" class="text-warning text-decoration-none small">
                                        /halaman/<?= $h['slug'] ?>.html
                                    </a>
                                </td>
                                <td class="small text-secondary">
                                    <?= date('d M Y', strtotime($h['updated_at'] ?? $h['created_at'] ?? 'now')) ?>
                                </td>
                                <td>
                                    <a href="halaman-admin.php?edit=<?= $h['slug'] ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="halaman-admin.php?delete=<?= $h['slug'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus halaman ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
