<?php include 'header.php'; ?>

<?php
$kategoriList = getAllKategori();
$error = '';

// Generate unique token untuk form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(16));
}
$formToken = $_SESSION['form_token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $kategori = $_POST['kategori'] ?? '';
    $isi = $_POST['isi'] ?? '';
    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'] ?? '')));
    $status = $_POST['status'] ?? 'draft';

    // Get image URL
    $gambar = trim($_POST['gambar'] ?? '');

    // Validation
    if (empty($judul) || empty($kategori) || empty($isi)) {
        $error = 'Judul, kategori, dan isi harus diisi!';
    } else {
        $berita = loadJson('berita.json');

        // Create slug
        $slug = createSlug($judul);

        // Check if exact same article exists (prevent double)
        $exactDuplicate = false;
        foreach ($berita as $b) {
            if ($b['kategori'] === $kategori && $b['slug'] === $slug && $b['judul'] === $judul) {
                $exactDuplicate = true;
                break;
            }
        }

        if ($exactDuplicate) {
            // Artikel sudah ada, redirect langsung tanpa simpan
            header('Location: berita.php?msg=added');
            exit;
        }

        // Generate new ID
        $maxId = 0;
        foreach ($berita as $b) {
            if ($b['id'] > $maxId) $maxId = $b['id'];
        }
        $newId = $maxId + 1;

        // Check duplicate slug (beda judul tapi slug sama)
        $slugExists = false;
        foreach ($berita as $b) {
            if ($b['kategori'] === $kategori && $b['slug'] === $slug) {
                $slugExists = true;
                break;
            }
        }
        if ($slugExists) {
            $slug .= '-' . $newId;
        }

        // Generate random rating
        $rating = generateRating();
        $reviewCount = generateReviewCount();

        // New berita
        $newBerita = [
            'id' => $newId,
            'judul' => $judul,
            'slug' => $slug,
            'isi' => $isi,
            'gambar' => $gambar,
            'kategori' => $kategori,
            'tags' => $tags,
            'views' => 0,
            'status' => $status,
            'rating' => $rating,
            'review_count' => $reviewCount,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $berita[] = $newBerita;
        saveJson('berita.json', $berita);

        // Generate HTML file if published
        if ($status === 'publish') {
            generateArtikelFile($newBerita);
            generateSitemap();
        }

        // Clear session token setelah berhasil
        unset($_SESSION['form_token']);

        header('Location: berita.php?msg=added');
        exit;
    }
}
?>

<h4 class="text-warning mb-4"><i class="bi bi-plus-circle"></i> Tambah Berita</h4>

<?php if ($error): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <form method="POST">
            <div class="row">
                <div class="col-md-8">
                    <div class="mb-3">
                        <label class="form-label">Judul Berita *</label>
                        <input type="text" name="judul" class="form-control" required value="<?= htmlspecialchars($_POST['judul'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Isi Berita *</label>
                        <textarea name="isi" class="form-control summernote"><?= htmlspecialchars($_POST['isi'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tags (pisahkan dengan koma)</label>
                        <input type="text" name="tags" class="form-control" placeholder="pragmatic, maxwin, gacor" value="<?= htmlspecialchars($_POST['tags'] ?? '') ?>">
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori" class="form-select" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($kategoriList as $kat): ?>
                            <option value="<?= $kat['id'] ?>" <?= ($_POST['kategori'] ?? '') === $kat['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($kat['nama']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">URL Gambar</label>
                        <input type="url" name="gambar" class="form-control" placeholder="https://example.com/gambar.jpg" value="<?= htmlspecialchars($_POST['gambar'] ?? '') ?>">
                        <small class="text-secondary">Masukkan link gambar dari CDN atau hosting gambar</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= ($_POST['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="publish" <?= ($_POST['status'] ?? '') === 'publish' ? 'selected' : '' ?>>Publish</option>
                        </select>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-save"></i> Simpan Berita
                        </button>
                        <a href="berita.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
