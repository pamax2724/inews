<?php
// Generate default article placeholder image
header('Content-Type: image/png');
header('Cache-Control: max-age=31536000');

$width = 800;
$height = 450;

$image = imagecreatetruecolor($width, $height);

// Colors
$bgColor = imagecolorallocate($image, 30, 30, 30);
$goldColor = imagecolorallocate($image, 255, 215, 0);
$textColor = imagecolorallocate($image, 150, 150, 150);

// Fill background
imagefill($image, 0, 0, $bgColor);

// Draw border
imagerectangle($image, 0, 0, $width - 1, $height - 1, $goldColor);

// Draw icon (simple image placeholder)
$iconSize = 80;
$iconX = ($width - $iconSize) / 2;
$iconY = ($height - $iconSize) / 2 - 30;

// Draw simple image icon shape
imagefilledrectangle($image, $iconX, $iconY, $iconX + $iconSize, $iconY + $iconSize, $goldColor);
imagefilledrectangle($image, $iconX + 5, $iconY + 5, $iconX + $iconSize - 5, $iconY + $iconSize - 5, $bgColor);

// Draw mountain shape inside
$points = [
    $iconX + 15, $iconY + $iconSize - 15,
    $iconX + 35, $iconY + 25,
    $iconX + 50, $iconY + 45,
    $iconX + 65, $iconY + 20,
    $iconX + $iconSize - 15, $iconY + $iconSize - 15
];
imagefilledpolygon($image, $points, 5, $goldColor);

// Draw sun
imagefilledellipse($image, $iconX + 25, $iconY + 25, 15, 15, $goldColor);

// Add text
$text = "BERITA MAXWIN";
$fontSize = 5;
$textWidth = imagefontwidth($fontSize) * strlen($text);
$textX = ($width - $textWidth) / 2;
$textY = $iconY + $iconSize + 30;
imagestring($image, $fontSize, $textX, $textY, $text, $goldColor);

// Output
imagepng($image);
imagedestroy($image);
