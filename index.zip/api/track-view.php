<?php
// API untuk tracking views artikel
// Dipanggil via JavaScript dari halaman artikel statis

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once dirname(__DIR__) . '/includes/functions.php';

// Get artikel ID dari parameter
$artikelId = $_GET['id'] ?? $_POST['id'] ?? null;

if (!$artikelId) {
    echo json_encode(['success' => false, 'message' => 'ID artikel tidak ditemukan']);
    exit;
}

// Cek apakah sudah pernah view dalam session ini
$sessionKey = 'viewed_' . $artikelId;
if (isset($_SESSION[$sessionKey])) {
    echo json_encode(['success' => true, 'message' => 'Already viewed']);
    exit;
}

// Increment views
$berita = loadJson('berita.json');
$found = false;

foreach ($berita as &$b) {
    if ($b['id'] == $artikelId) {
        $b['views'] = ($b['views'] ?? 0) + 1;
        $found = true;
        $_SESSION[$sessionKey] = true;
        break;
    }
}

if ($found) {
    saveJson('berita.json', $berita);
    echo json_encode(['success' => true, 'message' => 'View tracked']);
} else {
    echo json_encode(['success' => false, 'message' => 'Artikel tidak ditemukan']);
}
