<?php
// API untuk get views artikel
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once dirname(__DIR__) . '/includes/functions.php';

$artikelId = $_GET['id'] ?? null;

if (!$artikelId) {
    echo json_encode(['success' => false, 'views' => 0]);
    exit;
}

$berita = loadJson('berita.json');

foreach ($berita as $b) {
    if ($b['id'] == $artikelId) {
        echo json_encode(['success' => true, 'views' => $b['views'] ?? 0]);
        exit;
    }
}

echo json_encode(['success' => false, 'views' => 0]);
